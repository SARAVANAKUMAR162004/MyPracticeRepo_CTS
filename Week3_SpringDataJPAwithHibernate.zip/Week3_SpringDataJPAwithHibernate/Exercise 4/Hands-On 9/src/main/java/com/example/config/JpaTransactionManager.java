
public class JpaTransactionManager {

}
