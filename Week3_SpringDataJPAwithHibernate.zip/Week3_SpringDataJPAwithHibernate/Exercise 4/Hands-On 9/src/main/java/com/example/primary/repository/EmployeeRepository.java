

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
}
