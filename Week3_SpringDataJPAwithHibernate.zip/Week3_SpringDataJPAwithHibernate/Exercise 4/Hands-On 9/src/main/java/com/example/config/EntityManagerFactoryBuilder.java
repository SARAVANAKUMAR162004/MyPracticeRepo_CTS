import javax.sql.DataSource;

public class EntityManagerFactoryBuilder {

    public Object dataSource(DataSource primaryDataSource) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'dataSource'");
    }

}
