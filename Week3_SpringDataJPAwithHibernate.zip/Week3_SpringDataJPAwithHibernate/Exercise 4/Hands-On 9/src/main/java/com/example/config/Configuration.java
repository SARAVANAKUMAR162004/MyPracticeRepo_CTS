
public @interface Configuration {

}
