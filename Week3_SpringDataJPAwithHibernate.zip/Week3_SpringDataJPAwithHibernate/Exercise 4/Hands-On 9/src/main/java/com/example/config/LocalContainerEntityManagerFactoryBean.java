
public class LocalContainerEntityManagerFactoryBean {

    public Object getObject() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getObject'");
    }

}
