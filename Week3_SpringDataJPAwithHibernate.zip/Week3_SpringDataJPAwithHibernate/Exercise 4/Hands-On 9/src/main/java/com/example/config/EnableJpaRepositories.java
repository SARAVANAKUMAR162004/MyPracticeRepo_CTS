
public @interface EnableJpaRepositories {

    String basePackages();

    String entityManagerFactoryRef();

    String transactionManagerRef();

}
