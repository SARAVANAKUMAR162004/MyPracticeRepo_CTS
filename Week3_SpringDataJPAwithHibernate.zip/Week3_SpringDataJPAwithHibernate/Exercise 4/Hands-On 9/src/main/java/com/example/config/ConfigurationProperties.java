
public @interface ConfigurationProperties {

    String value();

}
