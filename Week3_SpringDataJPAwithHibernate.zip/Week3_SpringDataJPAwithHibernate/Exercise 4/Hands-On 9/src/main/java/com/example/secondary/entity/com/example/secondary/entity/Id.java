package com.example.secondary.entity;

public @interface Id {

}
