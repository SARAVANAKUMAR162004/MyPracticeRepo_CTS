
public class PlatformTransactionManager {

}
