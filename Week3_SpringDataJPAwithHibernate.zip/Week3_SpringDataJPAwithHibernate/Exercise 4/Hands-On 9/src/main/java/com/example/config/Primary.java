
public @interface Primary {

}
