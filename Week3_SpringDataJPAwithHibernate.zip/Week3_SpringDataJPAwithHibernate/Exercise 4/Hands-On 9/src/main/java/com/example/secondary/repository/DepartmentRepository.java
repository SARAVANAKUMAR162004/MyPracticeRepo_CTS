

import com.example.secondary.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
}
