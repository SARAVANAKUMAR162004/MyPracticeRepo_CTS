
public class DataSourceProperties {

    public Object initializeDataSourceBuilder() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'initializeDataSourceBuilder'");
    }

}
