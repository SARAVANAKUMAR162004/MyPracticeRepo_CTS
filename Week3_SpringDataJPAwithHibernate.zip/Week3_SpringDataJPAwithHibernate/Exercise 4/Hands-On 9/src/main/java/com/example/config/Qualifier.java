
public @interface Qualifier {

    String value();

}
