# Employee Management System with Auditing

This is a Spring Boot application demonstrating entity auditing with JPA for Employee and Department entities.

## Features
- Tracks creation and modification of employees and departments
- Uses @CreatedBy, @LastModifiedBy, @CreatedDate, and @LastModifiedDate
- Simple AuditorAware implementation

## How to Run
1. Add your database configuration to `application.properties`.
2. Build and run the application using your preferred IDE or with Maven/Gradle.

## Structure
- `Employee` and `Department` entities with auditing fields
- AuditorAware bean for current user

---

This is a minimal setup. Extend as needed for your use case.
