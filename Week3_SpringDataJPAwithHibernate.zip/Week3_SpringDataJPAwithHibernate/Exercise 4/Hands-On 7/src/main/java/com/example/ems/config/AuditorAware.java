package com.example.ems.config;

public class AuditorAware<T> {

}
