package com.example.ems;

public class SpringApplication {

    public static void run(Class<EmployeeManagementSystemApplication> class1, String[] args) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'run'");
    }

}
