package com.example.ems.config;

import java.util.Optional;

@Configuration
public class AuditorAwareConfig {
    @Bean
    public void auditorProvider() {
        // In a real app, fetch the logged-in user
        //return () -> Optional.of("system-user");
    }
}
