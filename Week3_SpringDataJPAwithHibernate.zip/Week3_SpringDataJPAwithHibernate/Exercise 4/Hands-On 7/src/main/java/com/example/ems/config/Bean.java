package com.example.ems.config;

public @interface Bean {

}
