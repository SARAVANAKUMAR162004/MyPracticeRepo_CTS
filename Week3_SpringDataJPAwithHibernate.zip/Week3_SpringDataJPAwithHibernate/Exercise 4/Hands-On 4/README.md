# Employee Management System

This is a Spring Boot application for managing employees and departments with full CRUD operations using Spring Data JPA and Hibernate. It uses an H2 in-memory database for demonstration purposes.

## How to Run

1. Make sure you have Java 17+ and Maven installed.
2. Run `mvn spring-boot:run` in the project root.
3. Access the REST endpoints at `http://localhost:8080`.

## Endpoints
- `/employees` - CRUD for employees
- `/departments` - CRUD for departments

## H2 Console
- Access at `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:testdb`)
