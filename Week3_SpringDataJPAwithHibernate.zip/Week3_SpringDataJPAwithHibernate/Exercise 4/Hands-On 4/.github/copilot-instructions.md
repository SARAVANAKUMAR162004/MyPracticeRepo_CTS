<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This project is a Spring Boot Employee Management System with CRUD operations for Employee and Department entities using Spring Data JPA and Hibernate. Use best practices for RESTful API design and JPA entity relationships.
