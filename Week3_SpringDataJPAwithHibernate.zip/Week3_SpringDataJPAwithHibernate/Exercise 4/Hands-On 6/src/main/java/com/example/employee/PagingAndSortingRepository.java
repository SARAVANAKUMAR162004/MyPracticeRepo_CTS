package com.example.employee;

public interface PagingAndSortingRepository<T1, T2> {

}
