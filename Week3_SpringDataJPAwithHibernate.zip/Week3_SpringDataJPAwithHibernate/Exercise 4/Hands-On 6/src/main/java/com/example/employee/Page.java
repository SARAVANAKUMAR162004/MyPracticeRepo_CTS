package com.example.employee;

public class Page<T> {

}
