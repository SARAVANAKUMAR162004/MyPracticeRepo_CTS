package com.example.employee;

public class SpringApplication {

    public static void run(Class<EmployeeManagementApplication> class1, String[] args) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'run'");
    }

}
