package com.example.employee;

public class Pageable {

}
