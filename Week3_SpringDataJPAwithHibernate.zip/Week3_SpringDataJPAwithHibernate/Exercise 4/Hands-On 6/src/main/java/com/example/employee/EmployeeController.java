package com.example.employee;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public Page<Employee> getEmployees(@PageableDefault(size = 5, sort = "id") Pageable pageable) {
        return employeeService.getAllEmployees(pageable);
    }
}
