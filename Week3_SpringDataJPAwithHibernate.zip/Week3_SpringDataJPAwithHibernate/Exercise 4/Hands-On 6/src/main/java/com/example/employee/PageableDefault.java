package com.example.employee;

public @interface PageableDefault {

    int size();

    String sort();

}
