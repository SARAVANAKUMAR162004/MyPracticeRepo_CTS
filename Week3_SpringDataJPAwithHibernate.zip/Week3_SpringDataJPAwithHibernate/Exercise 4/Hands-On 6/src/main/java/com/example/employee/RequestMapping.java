package com.example.employee;

public @interface RequestMapping {

    String value();

}
