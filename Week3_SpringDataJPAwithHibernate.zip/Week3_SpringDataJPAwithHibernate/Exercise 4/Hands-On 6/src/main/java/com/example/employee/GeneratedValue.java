package com.example.employee;

public @interface GeneratedValue {

    String strategy();

}
