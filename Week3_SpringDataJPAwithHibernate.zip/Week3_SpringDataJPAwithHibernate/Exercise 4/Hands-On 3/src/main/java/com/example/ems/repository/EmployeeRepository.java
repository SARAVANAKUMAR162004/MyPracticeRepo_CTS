package com.example.ems.repository;

import com.example.ems.entity.Employee;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // Derived query methods
    List<Employee> findByName(String name);

    List<Employee> findByDepartmentId(Long departmentId);

    List<Employee> findBySalaryGreaterThan(double salary);
}
