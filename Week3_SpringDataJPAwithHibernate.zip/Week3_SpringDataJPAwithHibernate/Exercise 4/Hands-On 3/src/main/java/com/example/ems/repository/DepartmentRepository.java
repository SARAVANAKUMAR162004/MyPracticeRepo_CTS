package com.example.ems.repository;

import com.example.ems.entity.Department;
import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
    // Derived query methods
    List<Department> findByName(String name);
}
