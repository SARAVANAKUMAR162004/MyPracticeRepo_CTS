package com.example.ems.entity;

public class GenerationType {

}
