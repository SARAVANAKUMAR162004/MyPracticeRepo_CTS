package com.example.employee.repository;

public interface JpaRepository<T1, T2> {

}
