package com.example.employee;

public @interface NamedQuery {

    String name();

    String query();

}
