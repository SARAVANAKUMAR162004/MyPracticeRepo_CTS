package com.example.employee.repository;

import com.example.employee.Employee;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // Query method using keywords
    List<Employee> findByDepartment(String department);

    List<Employee> findBySalaryGreaterThan(double salary);

    // Custom query using @Query annotation
    @Query(name = "", value = "")
    List<Employee> searchByName(@Param("name") String name);

    // Using named query
    @Query(name = "Employee.findByDepartment", value = "")
    List<Employee> getByDepartment(@Param("department") String department);

    @Query(name = "Employee.findBySalaryGreaterThan", value = "")
    List<Employee> getBySalaryGreaterThan(@Param("salary") double salary);
}
