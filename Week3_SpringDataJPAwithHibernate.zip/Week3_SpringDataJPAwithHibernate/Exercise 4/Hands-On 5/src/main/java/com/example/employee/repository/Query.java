package com.example.employee.repository;

public @interface Query {

    String value();

    String name();

}
