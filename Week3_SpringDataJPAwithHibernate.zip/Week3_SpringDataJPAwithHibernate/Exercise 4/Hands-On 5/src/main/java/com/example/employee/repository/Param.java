package com.example.employee.repository;

public @interface Param {

    String value();

}
