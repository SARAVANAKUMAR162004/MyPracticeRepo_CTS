package com.example.employee;

public @interface NamedQueries {

    NamedQuery[] value();

}
