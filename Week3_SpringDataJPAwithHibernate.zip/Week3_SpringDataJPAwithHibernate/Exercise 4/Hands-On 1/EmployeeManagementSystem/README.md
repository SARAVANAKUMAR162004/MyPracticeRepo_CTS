# EmployeeManagementSystem

A Spring Boot application for managing employee data and departments using Spring Data JPA, H2 Database, Spring Web, and Lombok.

## Features
- Manage employees and departments
- In-memory H2 database for development
- RESTful API endpoints

## Setup
1. Ensure you have Java 17+ installed.
2. Build and run the project using your IDE or with `mvn spring-boot:run` (if Maven is available).

## Configuration
The application uses an in-memory H2 database. See `src/main/resources/application.properties` for details.

## Endpoints
- `/employees` - Manage employees
- `/departments` - Manage departments

## Note
This is a starter template. Extend as needed for your use case.
