package com.example.ems.service;

public @interface Autowired {

}
