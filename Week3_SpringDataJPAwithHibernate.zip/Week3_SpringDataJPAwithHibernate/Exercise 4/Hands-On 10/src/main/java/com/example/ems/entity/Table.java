package com.example.ems.entity;

public @interface Table {

    String name();

}
