package com.example.ems.repository;

public @interface Repository {

}
