package com.example.ems;

public @interface SpringBootApplication {

}
