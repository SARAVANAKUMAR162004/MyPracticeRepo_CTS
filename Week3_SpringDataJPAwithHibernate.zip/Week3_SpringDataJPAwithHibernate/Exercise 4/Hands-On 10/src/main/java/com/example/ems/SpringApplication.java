package com.example.ems;

public class SpringApplication {

    public static void run(Class<EmsApplication> class1, String[] args) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'run'");
    }

}
