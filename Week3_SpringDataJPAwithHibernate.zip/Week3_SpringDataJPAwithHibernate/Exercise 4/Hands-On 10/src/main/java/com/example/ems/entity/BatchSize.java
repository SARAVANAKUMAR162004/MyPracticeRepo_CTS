package com.example.ems.entity;

public @interface BatchSize {

    int size();

}
