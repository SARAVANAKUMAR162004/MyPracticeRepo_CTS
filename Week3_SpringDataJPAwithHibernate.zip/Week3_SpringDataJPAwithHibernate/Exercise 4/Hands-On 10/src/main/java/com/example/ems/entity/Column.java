package com.example.ems.entity;

public @interface Column {

    boolean nullable();

}
