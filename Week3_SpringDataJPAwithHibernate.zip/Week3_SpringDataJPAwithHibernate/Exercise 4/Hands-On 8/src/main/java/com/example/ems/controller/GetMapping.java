package com.example.ems.controller;

public @interface GetMapping {

    String value();

}
