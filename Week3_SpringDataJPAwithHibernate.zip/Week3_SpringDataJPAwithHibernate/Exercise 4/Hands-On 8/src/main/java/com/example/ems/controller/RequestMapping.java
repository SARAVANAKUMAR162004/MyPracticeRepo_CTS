package com.example.ems.controller;

public @interface RequestMapping {

    String value();

}
