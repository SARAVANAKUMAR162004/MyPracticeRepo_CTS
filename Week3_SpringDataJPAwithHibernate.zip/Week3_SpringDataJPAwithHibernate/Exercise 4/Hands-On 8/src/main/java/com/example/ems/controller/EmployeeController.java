package com.example.ems.controller;

import com.example.ems.projection.EmployeeNameSalaryView;
import com.example.ems.projection.EmployeeNameDepartmentDTO;
import com.example.ems.repository.EmployeeRepository;
import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
    private final EmployeeRepository employeeRepository;

    public EmployeeController(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    // Interface-based projection
    @GetMapping("/names-salaries")
    public List<EmployeeNameSalaryView> getEmployeeNamesAndSalaries() {
        return employeeRepository.findBy();
    }

    // Class-based projection
    @GetMapping("/names-departments")
    public List<EmployeeNameDepartmentDTO> getEmployeeNamesAndDepartments() {
        return employeeRepository.fetchEmployeeNameAndDepartment();
    }
}
