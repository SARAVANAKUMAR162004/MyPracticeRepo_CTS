package com.example.ems.projection;

// Class-based projection for Employee name and Department name
public class EmployeeNameDepartmentDTO {
    private String name;
    private String departmentName;

    public EmployeeNameDepartmentDTO(String name, String departmentName) {
        this.name = name;
        this.departmentName = departmentName;
    }

    public String getName() {
        return name;
    }

    public String getDepartmentName() {
        return departmentName;
    }
}
