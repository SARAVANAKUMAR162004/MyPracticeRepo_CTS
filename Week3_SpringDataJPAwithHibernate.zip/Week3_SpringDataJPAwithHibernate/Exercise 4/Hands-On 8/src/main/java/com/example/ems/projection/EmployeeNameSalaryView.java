package com.example.ems.projection;

// Interface-based projection for Employee name and salary
public interface EmployeeNameSalaryView {
    String getName();

    double getSalary();
}
