package com.example.ems.repository;

import com.example.ems.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
}
