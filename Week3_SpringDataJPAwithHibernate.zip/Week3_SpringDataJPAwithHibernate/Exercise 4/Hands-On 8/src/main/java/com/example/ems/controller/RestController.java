package com.example.ems.controller;

public @interface RestController {

}
