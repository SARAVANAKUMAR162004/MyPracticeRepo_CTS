package com.example.ems.entity;

public @interface JoinColumn {

    String name();

}
