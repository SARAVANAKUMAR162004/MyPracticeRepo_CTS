package com.example.ems.entity;

public @interface OneToMany {

    String mappedBy();

    String cascade();

    boolean orphanRemoval();

}
