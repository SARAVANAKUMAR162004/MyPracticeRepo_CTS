package com.example.ems.entity;

public @interface ManyToOne {

    String fetch();

}
