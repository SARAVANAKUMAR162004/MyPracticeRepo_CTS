package com.example.ems.entity;

public class FetchType {

    public static final String LAZY = null;

}
