package com.example.ems.entity;

public class CascadeType {

    public static final String ALL = null;

}
