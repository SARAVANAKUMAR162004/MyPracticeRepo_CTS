
public record Configuration() {

}
