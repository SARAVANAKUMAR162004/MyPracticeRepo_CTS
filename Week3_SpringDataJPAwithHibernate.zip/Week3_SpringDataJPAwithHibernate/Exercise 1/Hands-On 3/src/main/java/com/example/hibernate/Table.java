
public @interface Table {

}
