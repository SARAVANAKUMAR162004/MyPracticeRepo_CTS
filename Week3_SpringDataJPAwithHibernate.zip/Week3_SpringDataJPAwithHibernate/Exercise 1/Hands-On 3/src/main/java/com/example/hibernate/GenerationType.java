
public class GenerationType {

}
