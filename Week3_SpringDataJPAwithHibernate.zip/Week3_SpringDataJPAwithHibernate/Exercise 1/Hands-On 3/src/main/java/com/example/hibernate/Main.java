package com.example.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {
        // Create configuration instance & pass hibernate configuration file
        Configuration config = new Configuration();
        config.configure("hibernate.cfg.xml");

        // Create SessionFactory instance
        SessionFactory factory = config.buildSessionFactory();

        // Get session object
        Session session = factory.openSession();

        // Start transaction
        Transaction t = session.beginTransaction();

        // Create Employee object
        Employee emp = new Employee("John", "Doe", 50000);
        session.save(emp);

        t.commit();
        System.out.println("Employee saved successfully");

        session.close();
        factory.close();
    }
}
