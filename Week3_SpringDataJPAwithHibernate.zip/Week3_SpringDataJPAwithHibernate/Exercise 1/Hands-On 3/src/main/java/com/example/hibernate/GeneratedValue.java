
public @interface GeneratedValue {

}
