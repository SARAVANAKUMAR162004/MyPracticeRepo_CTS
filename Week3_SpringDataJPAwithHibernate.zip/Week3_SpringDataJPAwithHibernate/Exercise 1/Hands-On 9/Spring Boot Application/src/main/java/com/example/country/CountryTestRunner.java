package com.example.country;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class CountryTestRunner implements CommandLineRunner {
    @Autowired
    private CountryService countryService;

    @Override
    public void run(String... args) throws Exception {
        // Example: update country with code "IN" to new name "Bharat"
        countryService.updateCountry("IN", "Bharat");
        System.out.println("Country name updated for code IN");

        // Test deleting a country by code
        countryService.deleteCountry("IN");
        System.out.println("Country deleted for code IN");
    }
}
