# Library Management Spring Boot Application

This is a simple Spring Boot application for managing a library's books. It demonstrates CRUD operations using Spring Web, Spring Data JPA, and an in-memory H2 database.

## Features
- Add, view, update, and delete books
- RESTful API endpoints
- In-memory H2 database (with web console enabled)

## How to Run
1. Make sure you have Java 17+ and Maven installed.
2. In the project root, run:
   ```
mvn spring-boot:run
   ```
3. Access the API at `http://localhost:8080/books`
4. Access the H2 console at `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:librarydb`)

## Endpoints
- `GET /books` - List all books
- `GET /books/{id}` - Get a book by ID
- `POST /books` - Add a new book
- `PUT /books/{id}` - Update a book
- `DELETE /books/{id}` - Delete a book
