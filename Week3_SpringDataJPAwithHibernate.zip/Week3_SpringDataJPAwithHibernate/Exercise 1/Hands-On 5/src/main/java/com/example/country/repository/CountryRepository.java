package com.example.country.repository;

import com.example.country.entity.Country;
import java.util.List;

@Repository
public interface CountryRepository extends JpaRepository<Country, String> {
    Country findByCode(String code);

    List<Country> findByNameContainingIgnoreCase(String name);

    Country save(Country country);

    void deleteById(String code);
}
