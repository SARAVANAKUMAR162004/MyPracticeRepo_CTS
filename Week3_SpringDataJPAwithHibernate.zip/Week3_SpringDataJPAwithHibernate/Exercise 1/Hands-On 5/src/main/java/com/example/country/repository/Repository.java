package com.example.country.repository;

public @interface Repository {

}
