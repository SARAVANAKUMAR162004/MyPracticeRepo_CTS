package com.example.country.service;

public @interface Service {

}
