package com.example.country.repository;

public interface JpaRepository<T1, T2> {

}
