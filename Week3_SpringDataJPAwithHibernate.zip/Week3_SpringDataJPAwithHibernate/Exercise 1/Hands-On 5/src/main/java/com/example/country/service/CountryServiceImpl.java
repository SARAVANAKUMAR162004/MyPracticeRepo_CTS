package com.example.country.service;

import com.example.country.entity.Country;
import com.example.country.repository.CountryRepository;
import java.util.List;

@Service
public class CountryServiceImpl implements CountryService {

    @Autowired
    private CountryRepository countryRepository;

    @Override
    public Country findByCode(String code) {
        return countryRepository.findByCode(code);
    }

    @Override
    public Country addCountry(Country country) {
        return countryRepository.save(country);
    }

    @Override
    public Country updateCountry(String code, Country country) {
        Country existing = countryRepository.findByCode(code);
        if (existing.isPresent()) {
            Country c = existing.get();
            c.setName(country.getName());
            return countryRepository.save(c);
        }
        return null;
    }

    @Override
    public void deleteCountry(String code) {
        countryRepository.deleteById(code);
    }

    @Override
    public List<Country> findByPartialName(String partialName) {
        return countryRepository.findByNameContainingIgnoreCase(partialName);
    }
}
