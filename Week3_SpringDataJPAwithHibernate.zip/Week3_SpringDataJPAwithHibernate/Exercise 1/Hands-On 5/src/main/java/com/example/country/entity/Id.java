package com.example.country.entity;

public @interface Id {

}
