package com.example.country.service;

import com.example.country.entity.Country;
import java.util.List;

public interface CountryService {
    Country findByCode(String code);

    Country addCountry(Country country);

    Country updateCountry(String code, Country country);

    void deleteCountry(String code);

    List<Country> findByPartialName(String partialName);
}
