package com.example.country.entity;

public @interface Column {

}
