
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
}

@Service
public class EmployeeSpringDataJPAService {
    @Autowired
    private EmployeeRepository employeeRepository;

    @Transactional
    public void addEmployee(Employee employee) {
        employeeRepository.save(employee);
    }
}

// Note: The Employee class should be a JPA entity with appropriate annotations.
