# orm-learn

Demo project for Spring Data JPA and Hibernate.

## Requirements
- Java 8 or above
- Maven 3.6.2 or above
- MySQL Server 8.0

## How to build

    mvn clean package

## How to run

    mvn spring-boot:run

## Database
- Create schema `ormlearn` in MySQL before running the application.
