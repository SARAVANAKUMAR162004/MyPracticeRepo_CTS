package com.cognizant.springlearn.repository;

public @interface Repository {

}
