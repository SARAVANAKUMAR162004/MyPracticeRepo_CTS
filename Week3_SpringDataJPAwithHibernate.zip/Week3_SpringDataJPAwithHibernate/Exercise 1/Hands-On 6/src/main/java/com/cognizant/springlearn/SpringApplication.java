package com.cognizant.springlearn;

public class SpringApplication {

}
