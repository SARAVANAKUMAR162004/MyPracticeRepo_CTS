package com.cognizant.springlearn.repository;

public interface JpaRepository<T1, T2> {

}
