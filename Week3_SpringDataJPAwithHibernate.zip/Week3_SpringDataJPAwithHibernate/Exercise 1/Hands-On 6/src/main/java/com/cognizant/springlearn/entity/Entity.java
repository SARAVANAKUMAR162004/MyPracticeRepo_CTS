package com.cognizant.springlearn.entity;

public @interface Entity {

}
