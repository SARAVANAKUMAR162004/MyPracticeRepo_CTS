package com.cognizant.springlearn.service;

public @interface Autowired {

}
