# Country Code Spring Boot Application

This project demonstrates a simple Spring Boot application using Spring Data JPA and Hibernate to manage countries. It includes:
- Country entity
- CountryRepository
- CountryService with exception handling
- Main application class with a test method to find a country by code

## How to Run
1. Ensure you have Java and Maven installed.
2. Add your database configuration in `src/main/resources/application.properties`.
3. Run the application using:
   ```
   mvn spring-boot:run
   ```

## Features
- Find country by code with exception handling
- Uses @Transactional for service methods

## Note
- Update the database and table as per your environment.
