package com.cognizant.ormlearn.repository;

public interface JpaRepository<T1, T2> {

}
