package com.cognizant.ormlearn.model;

public class GenerationType {

}
