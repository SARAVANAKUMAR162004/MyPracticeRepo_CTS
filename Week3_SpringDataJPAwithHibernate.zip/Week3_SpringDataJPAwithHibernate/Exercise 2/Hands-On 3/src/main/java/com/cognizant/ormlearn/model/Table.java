package com.cognizant.ormlearn.model;

public @interface Table {

}
