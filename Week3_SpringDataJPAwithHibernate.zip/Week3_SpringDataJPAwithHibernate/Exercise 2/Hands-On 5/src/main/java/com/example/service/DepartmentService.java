package service;

public interface DepartmentService {
    Department get(Long id);
}
