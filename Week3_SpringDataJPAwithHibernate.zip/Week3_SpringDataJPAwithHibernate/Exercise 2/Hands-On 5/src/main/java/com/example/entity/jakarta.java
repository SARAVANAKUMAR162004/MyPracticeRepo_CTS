
public class jakarta {

    public static final String persistence = null;

}
