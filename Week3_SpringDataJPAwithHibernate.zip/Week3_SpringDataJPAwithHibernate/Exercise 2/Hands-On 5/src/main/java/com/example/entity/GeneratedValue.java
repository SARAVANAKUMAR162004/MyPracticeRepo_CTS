
public @interface GeneratedValue {

    String strategy();

}
