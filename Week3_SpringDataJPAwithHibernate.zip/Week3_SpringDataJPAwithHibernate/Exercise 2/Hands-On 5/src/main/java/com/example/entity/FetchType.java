
public class FetchType {

    public static final String EAGER = null;

}
