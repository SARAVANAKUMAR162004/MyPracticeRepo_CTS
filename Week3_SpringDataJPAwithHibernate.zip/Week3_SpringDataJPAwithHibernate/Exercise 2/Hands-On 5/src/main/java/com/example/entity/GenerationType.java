
public class GenerationType {

    public static final String IDENTITY = null;

}
