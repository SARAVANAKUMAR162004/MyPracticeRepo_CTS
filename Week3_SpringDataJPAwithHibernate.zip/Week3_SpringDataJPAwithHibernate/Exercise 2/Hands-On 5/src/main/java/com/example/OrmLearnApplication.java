import service.DepartmentService;

@SpringBootApplication
public class OrmLearnApplication implements CommandLineRunner {

    @Autowired
    private DepartmentService departmentService;

    public static void main(String[] args) {
        SpringApplication.run(OrmLearnApplication.class, args);
    }

    //@Override
    //public void run(String[] args) throws Exception {
       // testGetDepartment();
        // comment out other test methods if any
    //}

    //private void testGetDepartment() {
        //Object department = departmentService.get(1L); // Use an ID with multiple employees
        //((Object) LOGGER).info("Department: {}", department);
        //((Object) LOGGER).info("Employees: {}", department);
    //}
}
