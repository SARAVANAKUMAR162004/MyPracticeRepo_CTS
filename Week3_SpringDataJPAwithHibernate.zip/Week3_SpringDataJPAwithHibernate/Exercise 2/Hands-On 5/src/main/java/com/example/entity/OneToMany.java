
public @interface OneToMany {

    String mappedBy();

    String fetch();

}
