
public @interface ManyToOne {

}
