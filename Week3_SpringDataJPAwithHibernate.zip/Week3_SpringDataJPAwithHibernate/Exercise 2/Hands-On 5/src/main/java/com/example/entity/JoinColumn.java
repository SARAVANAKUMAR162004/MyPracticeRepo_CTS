
public @interface JoinColumn {

    String name();

}
