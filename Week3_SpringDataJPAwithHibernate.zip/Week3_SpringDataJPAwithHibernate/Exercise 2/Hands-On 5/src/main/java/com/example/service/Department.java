package service;

public class Department {

}
