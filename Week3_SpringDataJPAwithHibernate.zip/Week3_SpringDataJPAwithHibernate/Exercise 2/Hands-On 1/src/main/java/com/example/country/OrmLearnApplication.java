package com.example.country;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class OrmLearnApplication {
    public static void main(String[] args) {
        SpringApplication.run(OrmLearnApplication.class, args);
    }

    @Bean
    public CommandLineRunner testCountryRepository(@Autowired CountryRepository countryRepository) {
        return args -> {
            // Sample data
            List<Country> countries = Arrays.asList(
                    new Country("BV", "Bouvet Island"),
                    new Country("DJ", "Djibouti"),
                    new Country("GP", "Guadeloupe"),
                    new Country("GS", "South Georgia and the South Sandwich Islands"),
                    new Country("LU", "Luxembourg"),
                    new Country("SS", "South Sudan"),
                    new Country("TF", "French Southern Territories"),
                    new Country("UM", "United States Minor Outlying Islands"),
                    new Country("ZA", "South Africa"),
                    new Country("ZM", "Zambia"),
                    new Country("ZW", "Zimbabwe"));
            countryRepository.saveAll(countries);

            System.out.println("\nCountries containing 'ou':");
            countryRepository.findByNameContainingIgnoreCase("ou").forEach(System.out::println);

            System.out.println("\nCountries containing 'ou' (sorted):");
            countryRepository.findByNameContainingIgnoreCaseOrderByNameAsc("ou").forEach(System.out::println);

            System.out.println("\nCountries starting with 'Z':");
            countryRepository.findByNameStartingWithIgnoreCase("Z").forEach(System.out::println);
        };
    }
}
