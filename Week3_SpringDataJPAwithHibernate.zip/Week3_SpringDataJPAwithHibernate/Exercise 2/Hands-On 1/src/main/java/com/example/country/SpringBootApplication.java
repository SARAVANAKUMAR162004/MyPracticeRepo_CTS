
public @interface SpringBootApplication {

}
