package com.example.country;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CountryRepository extends JpaRepository<Country, String> {
    // Find countries containing a substring (case-insensitive)
    List<Country> findByNameContainingIgnoreCase(String name);

    // Find countries containing a substring, sorted by name ascending
    List<Country> findByNameContainingIgnoreCaseOrderByNameAsc(String name);

    // Find countries starting with a specific letter (case-insensitive)
    List<Country> findByNameStartingWithIgnoreCase(String prefix);
}
