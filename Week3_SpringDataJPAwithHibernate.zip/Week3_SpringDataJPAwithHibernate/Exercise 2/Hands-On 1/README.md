# Country Table Query Methods - Spring Boot Project

This project demonstrates the use of Spring Data JPA Query Methods for searching and sorting countries in a database.

## Features
- Search countries by substring (case-insensitive)
- Search countries by substring and sort by name ascending
- List countries starting with a specific letter
- Uses H2 in-memory database for easy testing

## How to Run
1. Build the project with Maven: `mvn clean install`
2. Run the application: `mvn spring-boot:run`

The main logic is in `OrmLearnApplication` and the repository is `CountryRepository`.
