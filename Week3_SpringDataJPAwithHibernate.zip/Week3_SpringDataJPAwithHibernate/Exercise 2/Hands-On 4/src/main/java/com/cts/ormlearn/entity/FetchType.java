package com.cts.ormlearn.entity;

public class FetchType {

}
