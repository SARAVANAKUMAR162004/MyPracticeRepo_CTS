package com.cts.ormlearn.repository;

public @interface Repository {

}
