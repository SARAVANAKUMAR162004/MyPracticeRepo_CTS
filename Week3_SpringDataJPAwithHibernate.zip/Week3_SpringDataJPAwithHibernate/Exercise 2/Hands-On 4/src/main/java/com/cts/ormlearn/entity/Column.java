package com.cts.ormlearn.entity;

public @interface Column {

}
