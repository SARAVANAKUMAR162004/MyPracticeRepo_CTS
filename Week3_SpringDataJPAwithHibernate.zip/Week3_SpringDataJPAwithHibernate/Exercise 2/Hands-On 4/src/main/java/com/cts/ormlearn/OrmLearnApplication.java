package com.cts.ormlearn;

import com.cts.ormlearn.entity.Employee;
import com.cts.ormlearn.entity.Department;
import com.cts.ormlearn.service.EmployeeService;
import com.cts.ormlearn.service.DepartmentService;
import com.cts.ormlearn.service.SkillService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class OrmLearnApplication {
    private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
    public static EmployeeService employeeService;
    public static DepartmentService departmentService;
    public static SkillService skillService;

    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
        employeeService = context.getBean(EmployeeService.class);
        departmentService = context.getBean(DepartmentService.class);
        skillService = context.getBean(SkillService.class);

        // Uncomment the test you want to run
        // testGetEmployee();
        // testAddEmployee();
        // testUpdateEmployee();
    }

    private static void testGetEmployee() {
        LOGGER.info("Start");
        Employee employee = employeeService.get(1);
        LOGGER.debug("Employee:{}", employee);
        LOGGER.debug("Department:{}", employee.getDepartment());
        LOGGER.info("End");
    }

    private static void testAddEmployee() {
        LOGGER.info("Start");
        Employee employee = new Employee();
        employee.setName("John Doe");
        employee.setSalary(50000);
        employee.setPermanent(true);
        employee.setDateOfBirth(new java.util.Date());
        Department department = departmentService.get(1);
        employee.setDepartment(department);
        employeeService.save(employee);
        LOGGER.debug("Employee: {}", employee);
        LOGGER.info("End");
    }

    private static void testUpdateEmployee() {
        LOGGER.info("Start");
        Employee employee = employeeService.get(1);
        Department department = departmentService.get(2); // Use a different department id
        employee.setDepartment(department);
        employeeService.save(employee);
        LOGGER.debug("Employee: {}", employee);
        LOGGER.info("End");
    }
}
