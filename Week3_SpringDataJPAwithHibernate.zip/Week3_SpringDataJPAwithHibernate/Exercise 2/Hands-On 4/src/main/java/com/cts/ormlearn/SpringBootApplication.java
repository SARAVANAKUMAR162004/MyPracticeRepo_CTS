package com.cts.ormlearn;

public @interface SpringBootApplication {

}
