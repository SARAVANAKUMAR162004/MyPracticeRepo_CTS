package com.cts.ormlearn.service;

public @interface Service {

}
