package com.cts.ormlearn;

public class SpringApplication {

}
