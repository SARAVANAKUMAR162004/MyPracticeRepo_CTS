package com.cts.ormlearn.service;

public class LOGGER {

}
