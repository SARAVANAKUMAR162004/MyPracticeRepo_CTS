package com.cts.ormlearn.entity;

public class TemporalType {

}
