package com.cts.ormlearn.entity;

public class GenerationType {

}
