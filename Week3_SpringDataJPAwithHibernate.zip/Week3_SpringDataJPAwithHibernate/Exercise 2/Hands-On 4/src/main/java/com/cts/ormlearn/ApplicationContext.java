package com.cts.ormlearn;

public class ApplicationContext {

}
