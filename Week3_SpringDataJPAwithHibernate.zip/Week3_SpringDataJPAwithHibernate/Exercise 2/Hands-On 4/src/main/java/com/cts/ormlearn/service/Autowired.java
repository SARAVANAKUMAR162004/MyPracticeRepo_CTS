package com.cts.ormlearn.service;

public @interface Autowired {

}
