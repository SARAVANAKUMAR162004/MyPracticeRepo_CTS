package com.cts.ormlearn.entity;

public @interface JoinColumn {

}
