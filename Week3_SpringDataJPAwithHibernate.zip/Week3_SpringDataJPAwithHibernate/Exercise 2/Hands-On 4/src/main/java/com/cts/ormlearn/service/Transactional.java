package com.cts.ormlearn.service;

public @interface Transactional {

}
