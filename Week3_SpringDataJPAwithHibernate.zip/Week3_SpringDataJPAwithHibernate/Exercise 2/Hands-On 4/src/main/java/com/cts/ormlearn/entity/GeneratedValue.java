package com.cts.ormlearn.entity;

public @interface GeneratedValue {

}
