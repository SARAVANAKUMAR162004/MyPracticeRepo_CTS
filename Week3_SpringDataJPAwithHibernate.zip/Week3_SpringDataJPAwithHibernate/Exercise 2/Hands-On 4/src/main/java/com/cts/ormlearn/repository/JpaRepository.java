package com.cts.ormlearn.repository;

public interface JpaRepository<T1, T2> {

}
