package com.example.ormlearn;

import com.example.ormlearn.entity.Stock;
import com.example.ormlearn.repository.StockRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@SpringBootApplication
public class OrmLearnApplication {
    public static void main(String[] args) {
        SpringApplication.run(OrmLearnApplication.class, args);
    }
}

@Component
class StockQueryRunner implements CommandLineRunner {
    @Autowired
    private StockRepository stockRepository;

    @Override
    public void run(String... args) {
        // 1. Facebook stocks in September 2019
        System.out.println("Facebook stocks in September 2019:");
        List<Stock> fbStocks = stockRepository.findByStCodeAndStDateBetween(
                "FB", LocalDate.of(2019, 9, 1), LocalDate.of(2019, 9, 30));
        fbStocks.forEach(System.out::println);

        // 2. Google stocks with price > 1250
        System.out.println("\nGoogle stocks with price > 1250:");
        List<Stock> googleStocks = stockRepository
                .findByStCodeAndStOpenGreaterThanOrStCodeAndStCloseGreaterThan(
                        "GOOGL", new BigDecimal("1250"), "GOOGL", new BigDecimal("1250"));
        googleStocks.forEach(System.out::println);

        // 3. Top 3 highest volume
        System.out.println("\nTop 3 highest volume:");
        List<Stock> topVolume = stockRepository.findTop3ByOrderByStVolumeDesc();
        topVolume.forEach(System.out::println);

        // 4. Netflix stocks with lowest close price
        System.out.println("\nNetflix stocks with lowest close price:");
        List<Stock> lowestNetflix = stockRepository.findTop3ByStCodeOrderByStCloseAsc("NFLX");
        lowestNetflix.forEach(System.out::println);
    }
}
