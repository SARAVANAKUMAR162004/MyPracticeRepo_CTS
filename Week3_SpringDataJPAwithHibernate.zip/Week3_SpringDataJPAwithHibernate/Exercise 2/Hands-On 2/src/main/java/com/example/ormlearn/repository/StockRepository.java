package com.example.ormlearn.repository;

import com.example.ormlearn.entity.Stock;
import org.springframework.data.jpa.repository.JpaRepository;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public interface StockRepository extends JpaRepository<Stock, Integer> {
    // 1. Facebook stocks in September 2019
    List<Stock> findByStCodeAndStDateBetween(String stCode, LocalDate startDate, LocalDate endDate);

    // 2. Google stocks with price > 1250 (either open or close)
    List<Stock> findByStCodeAndStOpenGreaterThanOrStCodeAndStCloseGreaterThan(
            String stCode1, BigDecimal price1, String stCode2, BigDecimal price2);

    // 3. Top 3 highest volume
    List<Stock> findTop3ByOrderByStVolumeDesc();

    // 4. Netflix stocks with lowest close price
    List<Stock> findTop3ByStCodeOrderByStCloseAsc(String stCode);
}
