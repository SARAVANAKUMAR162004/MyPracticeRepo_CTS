
public @interface Component {

}
