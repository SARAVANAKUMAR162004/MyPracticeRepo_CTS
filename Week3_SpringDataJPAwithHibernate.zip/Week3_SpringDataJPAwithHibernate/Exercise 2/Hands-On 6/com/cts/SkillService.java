package com.cts;

import com.cts.model.Skill;

public class SkillService {

    public Skill get(Long skillId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'get'");
    }

}
