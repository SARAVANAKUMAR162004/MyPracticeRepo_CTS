package com.cts;

public @interface Autowired {

}
