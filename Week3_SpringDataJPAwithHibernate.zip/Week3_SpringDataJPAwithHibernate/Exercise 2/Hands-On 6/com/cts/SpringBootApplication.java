package com.cts;

public @interface SpringBootApplication {

}
