package com.cts;

public class SpringApplication {

    public static void run(Class<OrmLearnApplication> class1, String[] args) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'run'");
    }

}
