package com.cts;

import java.lang.System.Logger;

public class LoggerFactory {

    public static Logger getLogger(Class<OrmLearnApplication> class1) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getLogger'");
    }

}
