package com.cts.model;

public @interface Id {

}
