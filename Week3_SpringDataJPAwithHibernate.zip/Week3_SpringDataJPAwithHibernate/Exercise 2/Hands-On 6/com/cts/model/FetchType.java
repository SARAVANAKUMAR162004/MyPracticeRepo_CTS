package com.cts.model;

public class FetchType {

    public static final String EAGER = null;

}
