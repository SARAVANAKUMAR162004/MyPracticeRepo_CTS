package com.cts.model;

public @interface ManyToMany {

    String fetch();

    String mappedBy();

}
