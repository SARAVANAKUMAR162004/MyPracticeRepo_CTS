package com.cts.model;

public @interface GeneratedValue {

    String strategy();

}
