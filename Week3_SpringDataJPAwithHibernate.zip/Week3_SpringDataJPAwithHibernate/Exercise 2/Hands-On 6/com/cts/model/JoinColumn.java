package com.cts.model;

public @interface JoinColumn {

}
