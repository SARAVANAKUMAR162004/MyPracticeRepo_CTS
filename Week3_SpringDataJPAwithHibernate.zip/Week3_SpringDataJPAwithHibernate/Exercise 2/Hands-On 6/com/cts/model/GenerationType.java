package com.cts.model;

public class GenerationType {

    public static final String IDENTITY = null;

}
