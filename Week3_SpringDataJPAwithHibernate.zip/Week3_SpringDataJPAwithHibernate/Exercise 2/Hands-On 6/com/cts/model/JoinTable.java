package com.cts.model;

public @interface JoinTable {

    String name();

    JoinColumn joinColumns();

}
