package com.cts.model;

public @interface Entity {

}
