package com.cts.model;

import java.util.HashSet;
import java.util.Set;

@Entity
public class Employee {

    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    //@ManyToMany(fetch = FetchType.EAGER)
   // @JoinTable(
        //name = "employee_skill";
        //joinColumns = @JoinColumn(name = "es_em_id"),
        //joinColumns = @JoinColumn(name = "es_sk_id"), joinColumns = null
   // )
    private Set<Skill> skillList = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Skill> getSkillList() {
        return skillList;
    }

    public void setSkillList(Set<Skill> skillList) {
        this.skillList = skillList;
    }

    public Object getDepartment() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getDepartment'");
    }
}
