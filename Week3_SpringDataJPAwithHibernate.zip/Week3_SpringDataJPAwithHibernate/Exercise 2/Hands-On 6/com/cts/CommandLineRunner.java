package com.cts;

public interface CommandLineRunner {

}
