package com.cts;

import com.cts.model.Employee;
import com.cts.model.Skill;

import java.util.Set;

@SpringBootApplication
public class OrmLearnApplication implements CommandLineRunner {
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private SkillService skillService;

    public static void main(String[] args) {
        SpringApplication.run(OrmLearnApplication.class, args);
    }

    //@Override
    //public void run(String... args) throws Exception {
       // void testAddSkillToEmployee() {
  //  }
        // testGetEmployee(); // Commented as per instructions
  //  }

   // public void testGetEmployee() {
        Employee employee = employeeService.get(1L); // Example ID
        //((Object) LOGGER).debug("Department:{}", employee.getDepartment());
        //((Object) LOGGER).debug("Skills:{}", employee.getSkillList());
   // }

    public void testAddSkillToEmployee() {
        Long employeeId = 1L; // Use an existing employee ID
        Long skillId = 2L; // Use an existing skill ID not already linked

        Employee employee = employeeService.get(employeeId);
        Skill skill = skillService.get(skillId);

        Set<Skill> skills = employee.getSkillList();
        skills.add(skill);
        employee.setSkillList(skills);

        employeeService.save(employee);
    }
}
