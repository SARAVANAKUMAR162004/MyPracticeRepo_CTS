# Library Management Application with Spring AOP Logging

This project demonstrates how to use Spring AOP for logging method execution times in a simple library management system.

## Features
- Logs execution time of service methods using a custom Aspect.
- Configured with XML (`applicationContext.xml`).
- Simple service for issuing and returning books.

## How to Run
1. Build the project:
   ```
   mvn clean package
   ```
2. Run the main class:
   ```
   mvn exec:java -Dexec.mainClass="com.library.LibraryManagementApplication"
   ```

## Project Structure
- `com.library.service.LibraryService`: Service with methods to issue/return books.
- `com.library.aspect.LoggingAspect`: Aspect that logs execution times.
- `applicationContext.xml`: Spring configuration with AspectJ support.

## Requirements
- Java 8 or higher
- Maven

## Output
Check the console for log messages showing method execution times.
