package com.cts.service;

public @interface Autowired {

}
