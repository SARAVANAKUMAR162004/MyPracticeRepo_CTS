package com.cts;

public @interface Bean {

}
