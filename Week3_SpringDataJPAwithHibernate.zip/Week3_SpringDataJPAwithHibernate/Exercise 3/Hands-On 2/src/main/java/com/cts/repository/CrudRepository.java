package com.cts.repository;

public interface CrudRepository<T1, T2> {

}
