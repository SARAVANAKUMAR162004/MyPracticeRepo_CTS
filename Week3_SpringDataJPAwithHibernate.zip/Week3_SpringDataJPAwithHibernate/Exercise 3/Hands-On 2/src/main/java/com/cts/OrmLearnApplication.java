package com.cts;

import com.cts.model.Employee;
import com.cts.service.Autowired;
import com.cts.service.EmployeeService;

import java.util.List;
import java.util.logging.Logger;

@SpringBootApplication
public class OrmLearnApplication {
    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(OrmLearnApplication.class);

    @Autowired
    private EmployeeService employeeService;

    public static void main(String[] args) {
        SpringApplication.run(OrmLearnApplication.class, args);
    }

    @Bean
    public void test(ApplicationContext ctx) {
        //return (args) -> {
            testGetAllPermanentEmployees();
        //};
    }

    public void testGetAllPermanentEmployees() {
        LOGGER.info("Start");
        List<Employee> employees = employeeService.getAllPermanentEmployees();
        //LOGGER.debug("Permanent Employees:{}", employees);
        //employees.forEach(e -> LOGGER.debug("Skills:{}", e.getSkillList()));
        LOGGER.info("End");
    }
}
