package com.cts.service;

public @interface Service {

}
