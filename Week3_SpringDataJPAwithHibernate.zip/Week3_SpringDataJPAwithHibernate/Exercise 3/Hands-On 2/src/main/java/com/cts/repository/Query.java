package com.cts.repository;

public @interface Query {

    String value();

}
