
public class TemporalType {

    public static final String TIMESTAMP = null;

}
