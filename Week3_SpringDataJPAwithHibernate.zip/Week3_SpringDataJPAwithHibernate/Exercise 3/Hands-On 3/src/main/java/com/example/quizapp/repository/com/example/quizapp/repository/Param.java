package com.example.quizapp.repository;

public @interface Param {

    String value();

}
