
public enum GenerationType {
    IDENTITY

}
