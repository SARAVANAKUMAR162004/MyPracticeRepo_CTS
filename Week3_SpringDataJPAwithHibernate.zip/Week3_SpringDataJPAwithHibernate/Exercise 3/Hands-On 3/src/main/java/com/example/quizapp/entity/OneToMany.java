
public @interface OneToMany {

    String mappedBy();

}
