package com.example.quizapp.repository;

public interface AttemptRepository extends JpaRepository<Attempt, Integer> {
    @Query("SELECT a FROM Attempt a " +
            "JOIN FETCH a.user u " +
            "JOIN FETCH a.attemptQuestions aq " +
            "JOIN FETCH aq.question q " +
            "JOIN FETCH q.options o " +
            "LEFT JOIN FETCH aq.attemptOptions ao " +
            "LEFT JOIN FETCH ao.option opt " +
            "WHERE u.id = :userId AND a.id = :attemptId")
    Attempt getAttempt(@Param("userId") int userId, @Param("attemptId") int attemptId);
}
