

import com.example.quizapp.service.AttemptService;

@SpringBootApplication
public class OrmLearnApplication {
    public static void main(String[] args) {
        SpringApplication.run(OrmLearnApplication.class, args);
    }

    @Bean
    public CommandLineRunner demo(ApplicationContext ctx) {
        //return args -> {
            AttemptService attemptService = ctx.getBean(AttemptService.class);
            int userId = 1; // example userId
            int attemptId = 1; // example attemptId
            Object attempt = attemptService.getAttempt(userId, attemptId);
            //System.out.println("Username: " + ((Object) attempt).getUser().getUsername());
            //System.out.println("Attempted Date: " + ((Object) attempt).getAttemptedDate());
            //for (AttemptQuestion aq : ((Object) attempt).getAttemptQuestions()) {
                Option aq = null;
                Question q = aq.getQuestion();
                System.out.println(q.getText());
                int idx = 1;
                for (Option opt : q.getOptions()) {
                    boolean isSelected = aq.getAttemptOptions().stream()
                            .anyMatch(ao -> ao.getOption().getId().equals(opt.getId()));
                    String correct = opt.isCorrect() ? "true" : "false";
                    System.out.printf(" %d) %-10s %4.1f   %s\n", idx++, opt.getText(), opt.getScore(), isSelected);
                }
                System.out.println();
                return null;
            }
        //};
    }
//}
