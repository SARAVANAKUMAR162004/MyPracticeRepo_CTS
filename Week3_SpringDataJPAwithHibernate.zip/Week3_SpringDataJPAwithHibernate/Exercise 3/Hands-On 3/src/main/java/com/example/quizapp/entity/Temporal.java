
public @interface Temporal {

    String value();

}
