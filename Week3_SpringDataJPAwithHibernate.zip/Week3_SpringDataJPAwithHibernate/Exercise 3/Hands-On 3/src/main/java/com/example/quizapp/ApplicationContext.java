import com.example.quizapp.service.AttemptService;

public class ApplicationContext {

    public AttemptService getBean(Class<AttemptService> class1) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getBean'");
    }

}
