
public @interface GeneratedValue {

    GenerationType strategy();

}
