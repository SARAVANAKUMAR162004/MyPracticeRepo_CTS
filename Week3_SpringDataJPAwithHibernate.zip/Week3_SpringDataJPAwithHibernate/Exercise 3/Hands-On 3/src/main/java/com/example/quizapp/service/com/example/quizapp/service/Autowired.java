package com.example.quizapp.service;

public @interface Autowired {

}
