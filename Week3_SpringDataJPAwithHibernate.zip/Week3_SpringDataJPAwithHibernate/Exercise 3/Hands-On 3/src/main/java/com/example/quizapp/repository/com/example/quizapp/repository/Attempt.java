package com.example.quizapp.repository;

public class Attempt {

}
