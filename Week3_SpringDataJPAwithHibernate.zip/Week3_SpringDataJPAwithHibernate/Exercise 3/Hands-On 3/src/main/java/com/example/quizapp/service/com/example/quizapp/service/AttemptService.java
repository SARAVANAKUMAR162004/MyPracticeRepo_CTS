package com.example.quizapp.service;

import com.example.quizapp.repository.Attempt;
import com.example.quizapp.repository.AttemptRepository;

@Service
public class AttemptService {
    @Autowired
    private AttemptRepository attemptRepository;

    public Attempt getAttempt(int userId, int attemptId) {
        return attemptRepository.getAttempt(userId, attemptId);
    }
}
