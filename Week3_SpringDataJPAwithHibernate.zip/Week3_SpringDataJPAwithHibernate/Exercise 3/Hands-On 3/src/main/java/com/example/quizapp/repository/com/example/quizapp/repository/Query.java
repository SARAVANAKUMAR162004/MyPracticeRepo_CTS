package com.example.quizapp.repository;

public @interface Query {

    String value();

}
