package com.example.quizapp.repository;

public interface JpaRepository<T1, T2> {

}
