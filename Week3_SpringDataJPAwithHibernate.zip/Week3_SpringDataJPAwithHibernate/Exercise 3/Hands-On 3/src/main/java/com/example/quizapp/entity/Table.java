
public @interface Table {

    String name();

}
