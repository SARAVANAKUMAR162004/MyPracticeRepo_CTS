import java.util.function.Predicate;

public class CriteriaQuery<T> {

    public Root<Product> from(Class<Product> class1) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'from'");
    }

    public void where(Predicate[] array) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'where'");
    }

}
