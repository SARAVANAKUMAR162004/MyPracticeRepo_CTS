import java.util.function.Predicate;

public class CriteriaBuilder {

    public CriteriaQuery<Product> createQuery(Class<Product> class1) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'createQuery'");
    }

    public Predicate like(Object object, String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'like'");
    }

    public Predicate equal(Object object, String customerReview) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'equal'");
    }

}
