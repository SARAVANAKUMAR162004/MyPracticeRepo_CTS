import java.util.*;
import java.util.function.Predicate;

@Entity
class Product {
    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String customerReview;
    private String hardDiskSize;
    private String ramSize;
    private String cpuSpeed;
    private String operatingSystem;
    private String weight;
    private String cpu;
    // getters and setters
}

public class ProductCriteriaQueryExample {
    public List<Product> searchProducts(EntityManager entityManager,
            String keyword,
            String customerReview,
            String hardDiskSize,
            String ramSize,
            String cpuSpeed,
            String operatingSystem,
            String weight,
            String cpu) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Product> cq = cb.createQuery(Product.class);
        Root<Product> product = cq.from(Product.class);

        List<Predicate> predicates = new ArrayList<>();
        if (keyword != null && !keyword.isEmpty()) {
            predicates.add(cb.like(product.get("name"), "%" + keyword + "%"));
        }
        if (customerReview != null) {
            predicates.add(cb.equal(product.get("customerReview"), customerReview));
        }
        if (hardDiskSize != null) {
            predicates.add(cb.equal(product.get("hardDiskSize"), hardDiskSize));
        }
        if (ramSize != null) {
            predicates.add(cb.equal(product.get("ramSize"), ramSize));
        }
        if (cpuSpeed != null) {
            predicates.add(cb.equal(product.get("cpuSpeed"), cpuSpeed));
        }
        if (operatingSystem != null) {
            predicates.add(cb.equal(product.get("operatingSystem"), operatingSystem));
        }
        if (weight != null) {
            predicates.add(cb.equal(product.get("weight"), weight));
        }
        if (cpu != null) {
            predicates.add(cb.equal(product.get("cpu"), cpu));
        }

        cq.where(predicates.toArray(new Predicate[0]));
        return (List<Product>) entityManager.createQuery(cq);
    }
}
