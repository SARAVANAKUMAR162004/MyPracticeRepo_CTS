package com.example.demo.repository;

public @interface Query {

    String value();

}
