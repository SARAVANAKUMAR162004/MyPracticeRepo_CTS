package com.example.demo.repository;

public @interface Param {

    String value();

}
