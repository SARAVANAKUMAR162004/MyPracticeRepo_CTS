package com.example.demo.entity;

public class GenerationType {

    public static final String IDENTITY = null;

}
