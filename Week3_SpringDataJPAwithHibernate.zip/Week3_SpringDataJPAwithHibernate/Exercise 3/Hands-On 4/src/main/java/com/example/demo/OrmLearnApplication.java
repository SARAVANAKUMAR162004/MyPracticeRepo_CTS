package com.example.demo;

import com.example.demo.service.Autowired;
import com.example.demo.service.EmployeeService;

@SpringBootApplication
public class OrmLearnApplication implements CommandLineRunner {
    @Autowired
    private EmployeeService employeeService;

    public static void main(String[] args) {
        SpringApplication.run(OrmLearnApplication.class, args);
    }
}
