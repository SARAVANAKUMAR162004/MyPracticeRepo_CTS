package com.example.demo.repository;

public interface JpaRepository<T1, T2> {

}
