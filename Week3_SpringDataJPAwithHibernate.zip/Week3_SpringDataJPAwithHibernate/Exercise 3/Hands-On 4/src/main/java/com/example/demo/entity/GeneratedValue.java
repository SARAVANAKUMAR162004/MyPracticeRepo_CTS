package com.example.demo.entity;

public @interface GeneratedValue {

    String strategy();

}
