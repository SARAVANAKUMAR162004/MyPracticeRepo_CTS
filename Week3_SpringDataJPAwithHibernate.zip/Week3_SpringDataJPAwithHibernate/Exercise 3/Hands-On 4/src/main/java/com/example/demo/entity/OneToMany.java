package com.example.demo.entity;

public @interface OneToMany {

    String mappedBy();

}
