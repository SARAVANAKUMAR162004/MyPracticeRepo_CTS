package com.example.demo.entity;

public @interface JoinColumn {

    String name();

}
