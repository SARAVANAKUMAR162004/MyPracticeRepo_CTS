package com.example.demo;

public interface CommandLineRunner {

}
