package com.cts.model;

public @interface Table {

    String name();

}
