package com.cts.repository;

public interface JpaRepository<T1, T2> {

}
