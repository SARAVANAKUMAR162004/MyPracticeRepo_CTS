package com.cts.repository;

public @interface Repository {

}
