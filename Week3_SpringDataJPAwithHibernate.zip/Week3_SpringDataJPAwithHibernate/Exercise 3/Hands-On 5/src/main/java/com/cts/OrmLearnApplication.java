package com.cts;

import com.cts.model.Employee;
import com.cts.service.Autowired;
import com.cts.service.EmployeeService;
import java.util.List;

@SpringBootApplication
public class OrmLearnApplication implements CommandLineRunner {
    @Autowired
    private EmployeeService employeeService;

    public static void main(String[] args) {
        SpringApplication.run(OrmLearnApplication.class, args);
    }
}
