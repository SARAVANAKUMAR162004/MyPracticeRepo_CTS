
import java.util.List;

import javax.management.Query;

public class HQLJPQLExamples {
    public void hqlExamples(Session session) {
        TypedQuery<Employee> query = null;
        //Query<Employee> query = session.createQuery(hql);
        query.setParameter("minSalary", 50000);
        List<Employee> results = query.list();
        //List<Employee> results = (List<Employee>) ((Object) query);

        // HQL UPDATE example
        String hqlUpdate = "UPDATE Employee SET salary = :newSalary WHERE id = :empId";
        Query updateQuery = session.createQuery(hqlUpdate);
        //((TypedQuery<Employee>) updateQuery).setParameter("newSalary", 60000);
        //((TypedQuery<Employee>) updateQuery).setParameter("empId", 1);
        //int updated = ((TypedQuery<Employee>) updateQuery).executeUpdate();

        // HQL DELETE example
        String hqlDelete = "DELETE FROM Employee WHERE id = :empId";
        Query deleteQuery = session.createQuery(hqlDelete);
        //((TypedQuery<Employee>) deleteQuery).setParameter("empId", 2);
        //int deleted = ((TypedQuery<Employee>) deleteQuery).executeUpdate();

        // HQL INSERT example (HQL only)
        String hqlInsert = "INSERT INTO Employee (id, name, salary) SELECT e.id, e.name, e.salary FROM EmployeeTemp e";
        Query insertQuery = session.createQuery(hqlInsert);
        //int inserted = ((TypedQuery<Employee>) insertQuery).executeUpdate();
    }

    public void jpqlExamples(EntityManager entityManager) {
        // JPQL SELECT example
        String jpql = "SELECT e FROM Employee e WHERE e.salary > :minSalary";
        TypedQuery<Employee> query = entityManager.createQuery(jpql, Employee.class);
        query.setParameter("minSalary", 50000);
        List<Employee> results = query.getResultList();

        // JPQL UPDATE example
        String jpqlUpdate = "UPDATE Employee e SET e.salary = :newSalary WHERE e.id = :empId";
        TypedQuery<Employee> updateQuery = entityManager.createQuery(jpqlUpdate, null);
        updateQuery.setParameter("newSalary", 60000);
        updateQuery.setParameter("empId", 1);
        int updated = updateQuery.executeUpdate();

        // JPQL DELETE example
        String jpqlDelete = "DELETE FROM Employee e WHERE e.id = :empId";
        TypedQuery<Employee> deleteQuery = entityManager.createQuery(jpqlDelete, null);
        deleteQuery.setParameter("empId", 2);
        int deleted = deleteQuery.executeUpdate();
    }
}
