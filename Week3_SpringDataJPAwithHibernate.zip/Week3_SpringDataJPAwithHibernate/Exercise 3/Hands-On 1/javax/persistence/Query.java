package javax.persistence;

public class Query {

    public void setParameter(String string, int i) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setParameter'");
    }

}
