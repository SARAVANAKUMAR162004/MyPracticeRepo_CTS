
public class EntityManager {

    public TypedQuery<Employee> createQuery(String jpql, Class<Employee> class1) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'createQuery'");
    }

}
