import javax.management.Query;

public class Session {

    public Query createQuery(String hql) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'createQuery'");
    }

}
