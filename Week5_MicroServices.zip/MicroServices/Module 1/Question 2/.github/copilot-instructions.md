<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This workspace contains a Spring Boot microservices system with:
- config-server (Spring Cloud Config Server)
- eureka-server (Spring Cloud Netflix Eureka)
- product-service (Product management, Eureka client)
- inventory-service (Inventory management, Eureka client)

Use Spring Cloud best practices for configuration and service discovery.
