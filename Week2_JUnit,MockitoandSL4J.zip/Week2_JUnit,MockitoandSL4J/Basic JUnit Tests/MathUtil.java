public class MathUtil {

    public int square(int number) {
        return number * number;
    }

    public boolean isEven(int number) {
        return number % 2 == 0;
    }

    public int max(int a, int b) {
        return (a > b) ? a : b;
    }
}
