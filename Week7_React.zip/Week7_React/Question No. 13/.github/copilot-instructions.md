<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This project demonstrates various ways of conditional rendering, list rendering, and the use of keys in React. Components include BookDetails, BlogDetails, CourseDetails, and CourseList. Use clear, modern React patterns and best practices.
