# Blogger App

This React app demonstrates:

- Various ways of conditional rendering (if/else, ternary, &&, switch, IIFE)
- Rendering multiple components
- List component and use of keys
- Extracting components with keys
- Using the map() function for rendering lists

## Components

- **BookDetails**: Shows book information
- **BlogDetails**: Shows blog information
- **CourseDetails**: Shows course information
- **CourseList**: Renders a list of courses using map()

## How to Run

1. Make sure you have Node.js and npm installed.
2. Install dependencies:
   ```
   npm install
   ```
3. Start the development server:
   ```
   npm start
   ```
4. Open your browser at http://localhost:3000

## Features

- Switch between Book, Blog, and Course details using buttons
- See different conditional rendering techniques in action
- List rendering with unique keys

---
