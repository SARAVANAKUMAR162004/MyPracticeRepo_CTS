import React from 'react';

const CourseDetails = ({ course }) => (
  <div className="card">
    <h3>Course Details</h3>
    <p><strong>Name:</strong> {course.name}</p>
    <p><strong>Instructor:</strong> {course.instructor}</p>
    <p><strong>Duration:</strong> {course.duration}</p>
  </div>
);

export default CourseDetails;
