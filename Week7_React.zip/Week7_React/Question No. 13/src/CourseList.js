import React from 'react';
import CourseDetails from './CourseDetails';

const CourseList = ({ courses }) => (
  <div>
    <h2>Course List</h2>
    {courses.map(course => (
      <CourseDetails key={course.id} course={course} />
    ))}
  </div>
);

export default CourseList;
