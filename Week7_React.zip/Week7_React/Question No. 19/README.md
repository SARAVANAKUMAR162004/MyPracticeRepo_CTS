# GitHub Client App

This React app fetches and displays a list of GitHub repository names for a given user.

## Features

- Enter a GitHub username and fetch their public repositories
- Uses Axios for API calls
- Includes unit tests for the GitClient class using Jest and mocking

## Getting Started

1. Install dependencies:
   ```
   npm install
   ```
2. Start the app:
   ```
   npm start
   ```
3. Run tests:
   ```
   npm test
   ```

## Files

- `src/GitClient.js`: API client for GitHub
- `src/App.js`: Main React component
- `src/GitClient.test.js`: Unit tests for GitClient
