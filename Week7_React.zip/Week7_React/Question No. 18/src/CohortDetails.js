import React from 'react';

const CohortDetails = ({ cohort }) => {
  if (!cohort) return <div>No Cohort Data</div>;
  return (
    <div className="cohort-details">
      <h3>{cohort.code}</h3>
      <p><strong>Name:</strong> {cohort.name}</p>
      <p><strong>Status:</strong> {cohort.status}</p>
      <p><strong>Start Date:</strong> {cohort.startDate}</p>
      <p><strong>End Date:</strong> {cohort.endDate}</p>
    </div>
  );
};

export default CohortDetails;
