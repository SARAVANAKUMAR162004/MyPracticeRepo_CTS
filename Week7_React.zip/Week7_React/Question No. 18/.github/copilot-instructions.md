<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This project is a React dashboard for Cognizant Academy cohorts. It uses Jest and Enzyme for unit testing. Generate tests for React components using modern best practices.
