# Cognizant Academy Cohorts Dashboard

This React app displays ongoing and completed cohorts. It includes unit tests using Jest and Enzyme.

## Getting Started

1. Install dependencies:
   ```sh
   npm install
   ```
2. Install Enzyme and its adapter:
   ```sh
   npm install --save-dev enzyme @wojtekmaj/enzyme-adapter-react-17
   ```
3. Run the tests:
   ```sh
   npm test
   ```

## Project Structure

- `src/CohortDetails.js`: Component to display cohort details
- `src/Cohort.js`: Array of cohort data
- `src/CohortDetails.test.js`: Unit tests for CohortDetails
- `src/setupTests.js`: Enzyme configuration

## Types of Router Components

- `<BrowserRouter>`
- `<HashRouter>`
- `<MemoryRouter>`
- `<Route>`
- `<Switch>` / `<Routes>`
- `<Link>` / `<NavLink>`

## Why Unit Testing in React?

- Ensures components work as expected
- Catches bugs early
- Facilitates refactoring
- Improves code quality

## Working with Jest and Enzyme

- Jest: Test runner and assertion library
- Enzyme: Utility for rendering and testing React components

---
