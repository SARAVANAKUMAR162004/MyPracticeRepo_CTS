import React, { useState } from 'react';

function UserPage() {
  const [booking, setBooking] = useState({ flight: '', name: '' });
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    setBooking({ ...booking, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (booking.flight && booking.name) {
      setSuccess(true);
    }
  };

  if (success) {
    return <div><h2>Booking Successful!</h2><p>Thank you, {booking.name}, for booking flight {booking.flight}.</p></div>;
  }

  return (
    <div>
      <h2>Book Your Ticket</h2>
      <form onSubmit={handleSubmit} style={{ margin: '0 auto', width: '300px' }}>
        <div>
          <label>Flight:
            <select name="flight" value={booking.flight} onChange={handleChange} required>
              <option value="">Select Flight</option>
              <option value="AI101">AI101 (Delhi - Mumbai)</option>
              <option value="AI202">AI202 (Chennai - Bangalore)</option>
            </select>
          </label>
        </div>
        <div style={{ marginTop: '10px' }}>
          <label>Name:
            <input type="text" name="name" value={booking.name} onChange={handleChange} required />
          </label>
        </div>
        <button type="submit" style={{ marginTop: '15px' }}>Book Ticket</button>
      </form>
    </div>
  );
}

export default UserPage;
