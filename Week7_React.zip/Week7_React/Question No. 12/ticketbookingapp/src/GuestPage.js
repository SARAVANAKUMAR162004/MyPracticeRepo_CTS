import React from 'react';

function GuestPage() {
  return (
    <div>
      <h2>Flight Details</h2>
      <table style={{ margin: '0 auto', borderCollapse: 'collapse', width: '60%' }} border="1">
        <thead>
          <tr>
            <th>Flight</th>
            <th>From</th>
            <th>To</th>
            <th>Time</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>AI101</td>
            <td>Delhi</td>
            <td>Mumbai</td>
            <td>10:00 AM</td>
          </tr>
          <tr>
            <td>AI202</td>
            <td>Chennai</td>
            <td>Bangalore</td>
            <td>2:00 PM</td>
          </tr>
        </tbody>
      </table>
      <p style={{ color: 'red', marginTop: '20px' }}>Please login to book tickets.</p>
    </div>
  );
}

export default GuestPage;
