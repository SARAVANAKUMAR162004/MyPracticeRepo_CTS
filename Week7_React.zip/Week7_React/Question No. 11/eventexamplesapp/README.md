# eventexamplesapp

A React application demonstrating event handling concepts:

- Counter with Increment/Decrement buttons
- Multiple event handlers on a button
- Passing arguments to event handlers
- Synthetic events
- Currency converter (INR to EUR)

## How to run

1. Install dependencies:
   ```powershell
   npm install
   ```
2. Start the app:
   ```powershell
   npm start
   ```

## Features

- Demonstrates React event naming conventions (camelCase)
- Shows use of `this` in class components
- Uses synthetic events for cross-browser compatibility
