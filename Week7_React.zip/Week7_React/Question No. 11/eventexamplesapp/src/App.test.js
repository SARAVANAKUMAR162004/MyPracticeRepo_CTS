import { render, screen } from '@testing-library/react';
import App from './App';

test('renders React Event Examples App heading', () => {
  render(<App />);
  const heading = screen.getByText(/React Event Examples App/i);
  expect(heading).toBeInTheDocument();
});
