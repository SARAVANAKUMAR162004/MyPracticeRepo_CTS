import React from 'react';

// Declare two arrays
const T20players = ['Virat Kohli', 'Rohit Sharma', 'KL Rahul', 'Hardik Pandya', 'Jasprit Bumrah'];
const RanjiTrophy = ['Cheteshwar Pujara', 'Ajinkya Rahane', 'Ravindra Jadeja', 'Mayank Agarwal', 'Prithvi Shaw'];

// Merge arrays using ES6 spread operator
const allPlayers = [...T20players, ...RanjiTrophy];

// Destructuring to get odd and even team players
const oddPlayers = allPlayers.filter((_, idx) => idx % 2 === 0);
const evenPlayers = allPlayers.filter((_, idx) => idx % 2 !== 0);

const IndianPlayers = () => (
  <div>
    <h2>Odd Team Players</h2>
    <ul>
      {oddPlayers.map(player => <li key={player}>{player}</li>)}
    </ul>
    <h2>Even Team Players</h2>
    <ul>
      {evenPlayers.map(player => <li key={player}>{player}</li>)}
    </ul>
    <h2>Merged Players</h2>
    <ul>
      {allPlayers.map(player => <li key={player}>{player}</li>)}
    </ul>
  </div>
);

export default IndianPlayers;
