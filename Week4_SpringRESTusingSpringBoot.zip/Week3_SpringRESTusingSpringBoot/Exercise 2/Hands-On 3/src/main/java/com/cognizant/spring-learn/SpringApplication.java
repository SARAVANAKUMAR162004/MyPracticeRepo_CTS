
public class SpringApplication {

}
