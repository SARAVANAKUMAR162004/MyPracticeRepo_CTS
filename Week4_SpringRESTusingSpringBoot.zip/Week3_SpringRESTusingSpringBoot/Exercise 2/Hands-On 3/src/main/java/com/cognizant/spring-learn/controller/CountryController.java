
@RestController
public class CountryController {
    @RequestMapping("/country")
    public Country getCountryIndia() {
        return new Country("IN", "India");
    }
}
