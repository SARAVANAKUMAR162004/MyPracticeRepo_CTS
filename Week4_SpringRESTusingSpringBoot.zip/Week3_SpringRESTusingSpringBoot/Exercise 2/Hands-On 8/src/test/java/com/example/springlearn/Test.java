package com.example.springlearn;

public @interface Test {

}
