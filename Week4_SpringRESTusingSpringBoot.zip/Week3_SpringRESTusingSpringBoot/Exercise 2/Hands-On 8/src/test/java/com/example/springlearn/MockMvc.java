package com.example.springlearn;

public class MockMvc {

    public ResultActions perform(Object object) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'perform'");
    }

}
