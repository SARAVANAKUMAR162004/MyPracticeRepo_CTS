package com.example.springlearn;

@SpringBootTest
@AutoConfigureMockMvc
public class SpringLearnApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testGetCountryException() throws Exception {
        // Assuming /country/invalid triggers the exception
        ResultActions actions = mockMvc.perform(get("/country/invalid"));
        //actions.andExpect(((Object) status()).isBadRequest());
        //actions.andExpect(((Object) status()).reason("Country Not found"));
    }

    private Object get(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'get'");
    }

    private Object status() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'status'");
    }
}
