package com.example.springlearn;

public class ResultActions {

}
