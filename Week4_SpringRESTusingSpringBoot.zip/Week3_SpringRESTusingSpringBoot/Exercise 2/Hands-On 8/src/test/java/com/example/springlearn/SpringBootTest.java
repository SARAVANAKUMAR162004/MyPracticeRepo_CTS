package com.example.springlearn;

public @interface SpringBootTest {

}
