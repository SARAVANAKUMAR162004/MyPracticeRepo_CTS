package com.example.springlearn;

public @interface AutoConfigureMockMvc {

}
