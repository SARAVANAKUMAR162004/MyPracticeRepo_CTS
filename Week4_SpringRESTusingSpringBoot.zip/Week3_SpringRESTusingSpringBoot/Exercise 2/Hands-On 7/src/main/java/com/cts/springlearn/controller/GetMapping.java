package com.cts.springlearn.controller;

public @interface GetMapping {

}
