package com.cts.springlearn.controller;

public @interface RestController {

}
