package com.cts.springlearn;

public class SpringApplication {

}
