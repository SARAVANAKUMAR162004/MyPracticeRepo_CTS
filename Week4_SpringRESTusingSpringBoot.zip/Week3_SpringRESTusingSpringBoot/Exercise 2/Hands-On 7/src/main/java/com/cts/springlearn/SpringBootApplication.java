package com.cts.springlearn;

public @interface SpringBootApplication {

}
