package com.cts.springlearn;

public @interface AutoConfigureMockMvc {

}
