package com.cts.springlearn;

public enum ResultActions {

}
