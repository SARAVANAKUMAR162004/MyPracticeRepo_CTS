package com.cts.springlearn;

public @interface Test {

}
