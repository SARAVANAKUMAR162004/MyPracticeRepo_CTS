package com.cts.springlearn;

public @interface Autowired {

}
