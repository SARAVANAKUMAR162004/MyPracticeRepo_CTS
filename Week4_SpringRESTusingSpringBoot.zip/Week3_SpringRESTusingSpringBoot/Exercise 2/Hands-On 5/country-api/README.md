# Country API

This is a Spring Boot REST API that returns country details based on country code (case insensitive).

## How to Run

1. Build the project:
   ```powershell
   mvn clean install
   ```
2. Run the application:
   ```powershell
   mvn spring-boot:run
   ```
3. Access the API:
   - Example: [http://localhost:8080/countries/in](http://localhost:8080/countries/in)

## Sample Response
```
{
  "code": "IN",
  "name": "India"
}
```

## Project Structure
- `CountryController`: REST controller for country endpoints
- `CountryService`: Service to fetch country by code from XML
- `Country`, `CountryList`: Model classes
- `country.xml`: Country data
