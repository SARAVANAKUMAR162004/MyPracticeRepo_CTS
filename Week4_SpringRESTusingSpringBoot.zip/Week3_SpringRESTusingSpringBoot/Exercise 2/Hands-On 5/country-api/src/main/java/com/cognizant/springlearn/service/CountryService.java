package com.cognizant.springlearn.service;

import com.cognizant.springlearn.model.Country;
import com.cognizant.springlearn.model.CountryList;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;

@Service
public class CountryService {
    private List<Country> countryList;

    @PostConstruct
    public void init() {
        try {
            InputStream is = new ClassPathResource("country.xml").getInputStream();
            JAXBContext context = JAXBContext.newInstance(CountryList.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            CountryList countries = (CountryList) unmarshaller.unmarshal(is);
            this.countryList = countries.getCountryList();
        } catch (Exception e) {
            throw new RuntimeException("Failed to load country.xml", e);
        }
    }

    public Country getCountry(String code) {
        Optional<Country> country = countryList.stream()
                .filter(c -> c.getCode().equalsIgnoreCase(code))
                .findFirst();
        return country.orElse(null);
    }
}
