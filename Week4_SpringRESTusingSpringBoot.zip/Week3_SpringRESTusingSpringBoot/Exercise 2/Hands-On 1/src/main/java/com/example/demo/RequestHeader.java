
public @interface RequestHeader {

    String value();

    boolean required();

}
