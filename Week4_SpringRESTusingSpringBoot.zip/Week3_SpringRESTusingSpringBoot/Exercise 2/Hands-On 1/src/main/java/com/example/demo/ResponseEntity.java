
public class ResponseEntity<T> {

    public static Object ok() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'ok'");
    }

}
