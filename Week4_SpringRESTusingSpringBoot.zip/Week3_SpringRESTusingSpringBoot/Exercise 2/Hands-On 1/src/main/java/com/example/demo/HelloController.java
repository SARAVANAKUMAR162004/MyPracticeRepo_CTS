

@RestController
public class HelloController {

    private static final Object ResponseEntity = null;

    @GetMapping("/hello.txt")
    public ResponseEntity<String> hello(
            @RequestHeader(value = "User-Agent", required = false) String userAgent,
            @RequestHeader(value = "Accept-Language", required = false) String acceptLanguage) {

        String response = "Hello World! My payload includes a trailing CRLF.\r\n";
        //return (ResponseEntity<String>) ((Object) ResponseEntity
                //.ok()
                //.header("Content-Type", "text/plain")
                //.header("Custom-User-Agent", userAgent != null ? userAgent : "Unknown")
                //.header("Custom-Accept-Language", acceptLanguage != null ? acceptLanguage : "Unknown")
                //.body(response);
        return null;
    }
}
