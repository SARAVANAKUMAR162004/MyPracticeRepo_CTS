package com.cognizant.springlearn.service;

import com.cognizant.springlearn.model.Country;
import com.cognizant.springlearn.service.exception.CountryNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CountryService {
    private static List<Country> countryList = new ArrayList<>();

    static {
        countryList.add(new Country("in", "India"));
        countryList.add(new Country("us", "United States"));
        countryList.add(new Country("uk", "United Kingdom"));
    }

    public Country getCountry(String code) {
        return countryList.stream()
                .filter(country -> country.getCode().equalsIgnoreCase(code))
                .findFirst()
                .orElseThrow(CountryNotFoundException::new);
    }
}
