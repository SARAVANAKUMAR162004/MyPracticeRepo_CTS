package com.cognizant.springlearn.controller;

public @interface PathVariable {

}
