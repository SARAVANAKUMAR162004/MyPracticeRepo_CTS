package com.cognizant.springlearn.controller;

public @interface Autowired {

}
