package com.cognizant.springlearn.service.exception;

public @interface ResponseStatus {

}
