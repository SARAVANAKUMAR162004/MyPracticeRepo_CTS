<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This is a Spring Boot REST API project. Please generate code in Java using Spring Boot conventions. The REST controller should be in the package com.cognizant.spring-learn.controller. Countries should be loaded from an XML file (country.xml) and returned as JSON.
