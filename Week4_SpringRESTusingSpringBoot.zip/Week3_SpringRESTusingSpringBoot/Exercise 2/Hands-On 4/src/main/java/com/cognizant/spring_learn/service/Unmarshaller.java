package com.cognizant.spring_learn.service;

import java.io.InputStream;

import com.cognizant.spring_learn.model.CountryList;

public class Unmarshaller {

    public CountryList unmarshal(InputStream is) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'unmarshal'");
    }

}
