package com.cognizant.spring_learn.controller;

public @interface GetMapping {

    String value();

}
