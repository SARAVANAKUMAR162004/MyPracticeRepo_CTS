package com.cognizant.spring_learn.service;

import com.cognizant.spring_learn.model.CountryList;

public class JAXBContext {

    public static JAXBContext newInstance(Class<CountryList> class1) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'newInstance'");
    }

    public Unmarshaller createUnmarshaller() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'createUnmarshaller'");
    }

}
