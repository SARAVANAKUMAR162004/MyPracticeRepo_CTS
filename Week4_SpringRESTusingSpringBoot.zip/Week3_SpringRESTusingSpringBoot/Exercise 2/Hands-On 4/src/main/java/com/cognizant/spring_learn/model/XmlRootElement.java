package com.cognizant.spring_learn.model;

public @interface XmlRootElement {

    String name();

}
