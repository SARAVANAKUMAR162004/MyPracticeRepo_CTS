package com.cognizant.spring_learn.model;

public @interface XmlElement {

    String name();

}
