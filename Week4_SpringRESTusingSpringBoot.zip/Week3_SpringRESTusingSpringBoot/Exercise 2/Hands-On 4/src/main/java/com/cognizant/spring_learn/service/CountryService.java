package com.cognizant.spring_learn.service;

import com.cognizant.spring_learn.model.Country;
import com.cognizant.spring_learn.model.CountryList;
import java.io.InputStream;
import java.util.List;

@Service
public class CountryService {
    public List<Country> getAllCountries() throws Exception {
        InputStream is = getClass().getClassLoader().getResourceAsStream("country.xml");
        JAXBContext jaxbContext = JAXBContext.newInstance(CountryList.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        CountryList countryList = (CountryList) unmarshaller.unmarshal(is);
        return countryList.getCountries();
    }
}
