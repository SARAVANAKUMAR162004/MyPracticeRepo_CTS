package com.cognizant.spring_learn.service;

public @interface Service {

}
