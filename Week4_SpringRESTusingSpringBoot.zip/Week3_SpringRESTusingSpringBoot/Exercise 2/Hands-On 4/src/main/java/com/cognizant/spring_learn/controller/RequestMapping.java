package com.cognizant.spring_learn.controller;

public @interface RequestMapping {

}
