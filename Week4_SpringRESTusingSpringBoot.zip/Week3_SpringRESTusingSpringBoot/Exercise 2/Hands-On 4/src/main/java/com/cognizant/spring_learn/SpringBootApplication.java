package com.cognizant.spring_learn;

public @interface SpringBootApplication {

}
