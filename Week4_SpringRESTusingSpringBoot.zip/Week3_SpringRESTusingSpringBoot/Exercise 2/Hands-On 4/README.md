# Spring Boot REST API: Get All Countries

This project provides a REST endpoint to return all countries from an XML file.

- Endpoint: `GET /countries`
- Controller: `com.cognizant.spring-learn.controller.CountryController`
- Data source: `country.xml` (list of countries with code and name)

## How to Run
1. Build the project with Maven: `mvn clean install`
2. Run the application: `mvn spring-boot:run`
3. Access the endpoint: [http://localhost:8083/countries](http://localhost:8083/countries)

## Sample Response
```
[
  { "code": "IN", "name": "India"},
  { "code": "US", "name": "United States"},
  { "code": "JP", "name": "Japan"},
  { "code": "DE", "name": "Germany"}
]
```
