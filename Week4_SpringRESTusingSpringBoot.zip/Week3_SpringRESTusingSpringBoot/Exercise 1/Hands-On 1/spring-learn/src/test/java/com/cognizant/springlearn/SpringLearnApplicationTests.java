package com.cognizant.springlearn;



@SpringBootTest
class SpringLearnApplicationTests {

    @Test
    void contextLoads() {
    }
}
