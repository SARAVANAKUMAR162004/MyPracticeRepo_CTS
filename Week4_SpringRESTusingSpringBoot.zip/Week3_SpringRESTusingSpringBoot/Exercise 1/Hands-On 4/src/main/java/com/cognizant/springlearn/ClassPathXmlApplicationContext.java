
public class ClassPathXmlApplicationContext {

    public Country getBean(String string, Class<Country> class1) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getBean'");
    }

}
