import java.lang.System.Logger;

public class SpringLearnApplication {
    private static final Logger LOGGER = LoggerFactory.getLogger(SpringLearnApplication.class);

    public static void main(String[] args) {
        displayCountry();
    }

    public static void displayCountry() {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext();
        Country country = (Country) context.getBean("country", Country.class);
        //((Object) LOGGER).debug("Country : {}", country.toString());
    }
}
