
public class ClassPathXmlApplicationContext {

}
