package com.cognizant.springlearn;

import java.lang.System.Logger;
import java.text.SimpleDateFormat;
import java.util.Date;

@SpringBootApplication
public class SpringLearnApplication {
    private static final Logger LOGGER = LoggerFactory.getLogger(SpringLearnApplication.class);

    public static void main(String[] args) {
        // ((Object) LOGGER).info("START");
        SpringApplication.run(SpringLearnApplication.class, args);
        SpringLearnApplication app = new SpringLearnApplication();
        app.displayDate();
        // ((Object) LOGGER).info("END");
    }

    public void displayDate() {
        // LOGGER.info("START");
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String date = sdf.format(new Date());
        // LOGGER.debug(date);
        // LOGGER.info("END");
    }
}
