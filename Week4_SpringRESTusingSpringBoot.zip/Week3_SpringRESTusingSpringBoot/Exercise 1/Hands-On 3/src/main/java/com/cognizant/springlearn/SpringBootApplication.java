package com.cognizant.springlearn;

public @interface SpringBootApplication {

}
