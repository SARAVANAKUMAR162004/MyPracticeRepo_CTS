package com.cognizant.springlearn;

public class LoggerFactory {

}
