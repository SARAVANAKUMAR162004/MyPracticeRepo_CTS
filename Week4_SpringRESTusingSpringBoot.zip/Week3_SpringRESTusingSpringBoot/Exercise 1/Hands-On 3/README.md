# SpringLearn

This is a simple Spring Boot application demonstrating SLF4J logging integration.

## Features
- Logs start and end of methods using SLF4J
- Logs date in debug mode
- Logging configuration is set in `application.properties`

## How to Run
1. Ensure you have Java and Maven installed.
2. Build and run the application using:
   ```
   mvn spring-boot:run
   ```

## Logging
- All logs are output to the console with the specified pattern.
- No `System.out.println()` is used; all output is via SLF4J logging.
