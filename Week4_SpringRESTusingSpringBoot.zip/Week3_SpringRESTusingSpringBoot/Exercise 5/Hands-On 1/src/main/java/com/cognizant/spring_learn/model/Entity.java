
public @interface Entity {

}
