

import java.util.Date;

public class CustomJwtGenerator {
    public static void main(String[] args) {
        String secretKey = "mycustomsecretkey1234567890123456"; // 32 chars for HS256

        String jwt = (String) ((Object) Jwts.builder());
                //.setHeaderParam("typ", "JWT")
                //.setHeaderParam("alg", "HS256")
                //.setSubject("customUser")
                //.claim("role", "developer")
               // .claim("email", "user@example.com")
                //.setIssuedAt(new Date())
                //.setExpiration(new Date(System.currentTimeMillis() + 600_000)) // 10 min expiry
                //.signWith(Keys.hmacShaKeyFor(secretKey.getBytes()), SignatureAlgorithm.HS256)
                //.compact();

        System.out.println("Generated JWT: " + jwt);
    }
}
