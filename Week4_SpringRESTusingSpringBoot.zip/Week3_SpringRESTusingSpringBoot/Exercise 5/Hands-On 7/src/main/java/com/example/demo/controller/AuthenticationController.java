package com.example.demo.controller;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestController
public class AuthenticationController {

    private static final Logger logger = LoggerFactory.getLogger(AuthenticationController.class);

    @PostMapping("/authenticate")
    public Map<String, Object> authenticate(@RequestParam String username) {
        logger.info("Authenticating user: {}", username);
        // Here you would normally validate the user credentials
        // For demo, we assume authentication is always successful
        String token = generateJwt(username);
        Map<String, Object> response = new HashMap<>();
        response.put("token", token);
        logger.info("Token generated and returned for user: {}", username);
        return response;
    }

    private String generateJwt(String user) {
        logger.info("Generating JWT token for user: {}", user);
        JwtBuilder builder = Jwts.builder();
        builder.setSubject(user);
        builder.setIssuedAt(new Date());
        builder.setExpiration(new Date((new Date()).getTime() + 1200000)); // 20 minutes
        builder.signWith(SignatureAlgorithm.HS256, "secretkey");
        String token = builder.compact();
        logger.info("JWT token generated for user: {}", user);
        return token;
    }
}
