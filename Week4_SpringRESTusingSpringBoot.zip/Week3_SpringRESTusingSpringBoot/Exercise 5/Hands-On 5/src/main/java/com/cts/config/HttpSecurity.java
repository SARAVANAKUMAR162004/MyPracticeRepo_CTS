
public class HttpSecurity {

    public Object csrf() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'csrf'");
    }

    public SecurityFilterChain build() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'build'");
    }

}
