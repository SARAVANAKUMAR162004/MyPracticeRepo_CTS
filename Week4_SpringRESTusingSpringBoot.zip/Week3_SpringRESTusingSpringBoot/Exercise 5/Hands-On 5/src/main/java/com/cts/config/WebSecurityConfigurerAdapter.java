
public class WebSecurityConfigurerAdapter {

}
