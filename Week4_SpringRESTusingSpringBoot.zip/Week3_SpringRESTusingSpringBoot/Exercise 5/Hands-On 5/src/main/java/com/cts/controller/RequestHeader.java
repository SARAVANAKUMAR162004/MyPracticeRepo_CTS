
public @interface RequestHeader {

    String value();

}
