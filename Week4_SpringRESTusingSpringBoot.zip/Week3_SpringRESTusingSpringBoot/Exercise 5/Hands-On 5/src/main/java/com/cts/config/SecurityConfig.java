

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        // Uncomment and configure as needed:
        // http.csrf().disable()
        //     .authorizeRequests()
        //     .antMatchers("/countries").hasRole("USER")
        //     .antMatchers("/authenticate").hasAnyRole("USER", "ADMIN")
        //     .anyRequest().authenticated()
        //     .and()
        //     .httpBasic();
        return http.build();
    }
}
