

import java.lang.System.Logger;
import java.util.HashMap;
import java.util.Map;

@RestController
public class AuthenticationController {
    private static final Logger logger = LoggerFactory.getLogger(AuthenticationController.class);

    @GetMapping("/authenticate")
    public Map<String, String> authenticate(@RequestHeader("Authorization") String authHeader) {
        //((Object) logger).info("START - /authenticate");
        //logger.debug("Authorization header: {}", authHeader);
        Map<String, String> map = new HashMap<>();
        map.put("token", "");
        //logger.info("END - /authenticate");
        return map;
    }
}
