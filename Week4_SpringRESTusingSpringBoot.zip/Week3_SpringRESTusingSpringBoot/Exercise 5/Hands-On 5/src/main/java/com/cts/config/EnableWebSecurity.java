
public @interface EnableWebSecurity {

}
