
public @interface Bean {

}
