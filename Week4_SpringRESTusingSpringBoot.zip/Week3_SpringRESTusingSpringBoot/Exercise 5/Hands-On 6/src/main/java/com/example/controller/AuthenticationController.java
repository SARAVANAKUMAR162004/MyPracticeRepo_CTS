package com.example.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Base64;

@RestController
@RequestMapping("/api")
public class AuthenticationController {

    private static final Logger logger = LoggerFactory.getLogger(AuthenticationController.class);

    @GetMapping("/authenticate")
    public ResponseEntity<String> authenticate(@RequestHeader(value = "Authorization", required = false) String authHeader) {
        String user = getUser(authHeader);
        logger.debug("User from Authorization header: {}", user);
        if (user != null) {
            return ResponseEntity.ok("Authenticated user: " + user);
        } else {
            return ResponseEntity.status(401).body("Invalid or missing Authorization header");
        }
    }

    private String getUser(String authHeader) {
        logger.debug("Received Authorization header: {}", authHeader);
        if (authHeader == null || !authHeader.startsWith("Basic ")) {
            logger.debug("Authorization header is missing or does not start with 'Basic '");
            return null;
        }
        try {
            String encodedCredentials = authHeader.substring("Basic ".length());
            logger.debug("Encoded credentials: {}", encodedCredentials);
            byte[] decodedBytes = Base64.getDecoder().decode(encodedCredentials);
            String decodedCredentials = new String(decodedBytes);
            logger.debug("Decoded credentials: {}", decodedCredentials);
            int colonIndex = decodedCredentials.indexOf(':');
            if (colonIndex == -1) {
                logger.debug("Colon not found in decoded credentials");
                return null;
            }
            String username = decodedCredentials.substring(0, colonIndex);
            logger.debug("Extracted username: {}", username);
            return username;
        } catch (IllegalArgumentException e) {
            logger.error("Failed to decode credentials", e);
            return null;
        }
    }
}
