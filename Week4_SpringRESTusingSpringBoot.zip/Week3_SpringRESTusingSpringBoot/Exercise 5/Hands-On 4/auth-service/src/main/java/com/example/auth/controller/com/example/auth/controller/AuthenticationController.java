package com.example.auth.controller;

import com.example.auth.model.UserCredentials;
import com.example.auth.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
public class AuthenticationController {

    @Autowired
    private JwtUtil jwtUtil;

    @GetMapping("/authenticate")
    public ResponseEntity<?> authenticate(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Basic ")) {
            String base64Credentials = authHeader.substring("Basic ".length()).trim();
            String credentials = new String(java.util.Base64.getDecoder().decode(base64Credentials));
            String[] values = credentials.split(":", 2);
            String username = values[0];
            String password = values[1];

            // Here you would validate the username and password against your user store
            // For demonstration, we assume the credentials are valid
            String token = jwtUtil.generateToken(username);
            return ResponseEntity.ok(java.util.Collections.singletonMap("token", token));
        }
        return ResponseEntity.badRequest()
                .body(java.util.Collections.singletonMap("error", "Invalid Authorization header"));
    }
}