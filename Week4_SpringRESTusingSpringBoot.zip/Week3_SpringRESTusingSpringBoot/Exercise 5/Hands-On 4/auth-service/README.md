# Authentication Service

This project is an authentication service built using Spring Boot that generates and returns JSON Web Tokens (JWT) for user authentication.

## Features

- User authentication using JWT
- Secure configuration with Spring Security
- Simple REST API for authentication

## Project Structure

```
auth-service
├── src
│   ├── main
│   │   ├── java
│   │   │   └── com
│   │   │       └── example
│   │   │           └── auth
│   │   │               ├── AuthServiceApplication.java
│   │   │               ├── config
│   │   │               │   └── SecurityConfig.java
│   │   │               ├── controller
│   │   │               │   └── AuthenticationController.java
│   │   │               ├── model
│   │   │               │   └── UserCredentials.java
│   │   │               └── util
│   │   │                   └── JwtUtil.java
│   │   └── resources
│   │       └── application.properties
│   └── test
│       └── java
│           └── com
│               └── example
│                   └── auth
│                       └── AuthenticationControllerTest.java
├── pom.xml
└── README.md
```

## Setup Instructions

1. Clone the repository:
   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```
   cd auth-service
   ```

3. Build the project using Maven:
   ```
   mvn clean install
   ```

4. Run the application:
   ```
   mvn spring-boot:run
   ```

## Usage

To authenticate a user, send a POST request to `/authenticate` with the following headers:

```
Authorization: Basic <base64-encoded-username:password>
```

If the credentials are valid, the server will respond with a JWT token.

## Dependencies

This project uses the following dependencies:

- Spring Boot
- Spring Security
- JWT library

## License

This project is licensed under the MIT License.