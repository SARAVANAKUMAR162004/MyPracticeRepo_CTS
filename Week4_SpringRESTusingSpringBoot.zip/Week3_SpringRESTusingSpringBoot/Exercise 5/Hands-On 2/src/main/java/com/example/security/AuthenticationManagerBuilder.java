package com.example.security;

public class AuthenticationManagerBuilder {

}
