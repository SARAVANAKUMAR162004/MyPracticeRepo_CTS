package com.example.security;

public class SecurityFilterChain {

}
