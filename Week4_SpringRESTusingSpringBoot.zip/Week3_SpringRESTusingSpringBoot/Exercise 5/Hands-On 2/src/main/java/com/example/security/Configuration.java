package com.example.security;

public @interface Configuration {

}
