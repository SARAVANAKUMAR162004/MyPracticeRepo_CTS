package com.example.security;

@Configuration
public class CustomSecurityConfig {

    // Define two in-memory users: admin and user, both with password 'pwd'
   

    // Password encoder bean using BCrypt
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // Security filter chain configuration

}
