package com.example.security;

public @interface Bean {

}
