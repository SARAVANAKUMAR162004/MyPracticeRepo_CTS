package com.example.security;

public class HttpSecurity {

    public Object csrf() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'csrf'");
    }

    public SecurityFilterChain build() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'build'");
    }

    public Object httpBasic() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'httpBasic'");
    }

}
