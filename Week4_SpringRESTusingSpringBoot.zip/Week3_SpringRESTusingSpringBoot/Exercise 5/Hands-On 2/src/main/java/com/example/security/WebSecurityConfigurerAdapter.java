package com.example.security;

public class WebSecurityConfigurerAdapter {

}
