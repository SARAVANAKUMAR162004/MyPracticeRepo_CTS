package com.cognizant.springlearn;

public @interface Valid {

}
