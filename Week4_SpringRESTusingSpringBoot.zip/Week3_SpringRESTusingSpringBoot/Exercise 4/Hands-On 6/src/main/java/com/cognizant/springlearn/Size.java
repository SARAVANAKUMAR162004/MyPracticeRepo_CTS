package com.cognizant.springlearn;

public @interface Size {

    int min();

    int max();

    String message();

}
