package com.cognizant.springlearn;

public @interface RestController {

}
