package com.cognizant.springlearn;

public class ResponseEntity<T> {

}
