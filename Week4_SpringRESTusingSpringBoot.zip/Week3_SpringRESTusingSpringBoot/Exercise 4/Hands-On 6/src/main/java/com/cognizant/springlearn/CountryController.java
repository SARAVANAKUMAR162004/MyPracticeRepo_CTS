package com.cognizant.springlearn;

import java.lang.System.Logger;

@RestController
public class CountryController {
    private static final Logger LOGGER = LoggerFactory.getLogger(CountryController.class);

   // @PostMapping(value = "/countries", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Country addCountry(@RequestBody @Valid Country country) {
        //((Object) LOGGER).info("CountryController - addCountry called");
        // In a real app, you would save the country to a database here
        return country;
    }
}
