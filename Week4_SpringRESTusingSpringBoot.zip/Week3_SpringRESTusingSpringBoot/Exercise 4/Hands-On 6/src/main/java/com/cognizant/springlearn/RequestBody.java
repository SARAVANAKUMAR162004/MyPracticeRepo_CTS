package com.cognizant.springlearn;

public @interface RequestBody {

}
