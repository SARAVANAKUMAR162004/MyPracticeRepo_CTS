package com.cognizant.springlearn;

public @interface PostMapping {

    String consumes();

    String value();

    String produces();

}
