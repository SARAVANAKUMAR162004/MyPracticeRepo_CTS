package com.cognizant.springlearn;

public class SpringApplication {

    public static void run(Class<SpringLearnApplication> class1, String[] args) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'run'");
    }

}
