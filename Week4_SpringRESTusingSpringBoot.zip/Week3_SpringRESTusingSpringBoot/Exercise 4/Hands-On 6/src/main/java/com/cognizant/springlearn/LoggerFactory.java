package com.cognizant.springlearn;

import java.lang.System.Logger;

public class LoggerFactory {

    public static Logger getLogger(Class<?> clazz) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getLogger'");
    }

}
