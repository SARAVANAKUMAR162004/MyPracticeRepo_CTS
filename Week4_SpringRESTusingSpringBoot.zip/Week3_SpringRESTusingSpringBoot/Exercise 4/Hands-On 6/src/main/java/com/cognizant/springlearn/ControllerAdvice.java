package com.cognizant.springlearn;

public @interface ControllerAdvice {

}
