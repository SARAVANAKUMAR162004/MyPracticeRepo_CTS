package com.cognizant.springlearn;

public class MediaType {

    public static final String APPLICATION_JSON_VALUE = null;

}
