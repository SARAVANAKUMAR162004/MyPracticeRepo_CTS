package com.cognizant.springlearn;

public class ResponseEntityExceptionHandler {

}
