package com.example.demo.controller;

public @interface PostMapping {

}
