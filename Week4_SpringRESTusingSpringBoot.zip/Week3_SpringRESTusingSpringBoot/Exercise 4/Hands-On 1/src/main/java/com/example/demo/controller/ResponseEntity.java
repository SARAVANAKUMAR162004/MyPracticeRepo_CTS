package com.example.demo.controller;

import java.util.List;

public class ResponseEntity<T> {

    public static ResponseEntity<List<String>> ok(String arrayList) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'ok'");
    }

}
