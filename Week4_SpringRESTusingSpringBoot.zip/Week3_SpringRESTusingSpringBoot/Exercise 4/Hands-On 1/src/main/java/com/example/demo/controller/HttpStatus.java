package com.example.demo.controller;

public class HttpStatus {

    public static final String CREATED = null;
    public static final String NOT_FOUND = null;

}
