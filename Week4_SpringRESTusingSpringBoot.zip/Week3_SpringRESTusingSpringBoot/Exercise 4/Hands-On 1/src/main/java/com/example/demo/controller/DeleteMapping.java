package com.example.demo.controller;

public @interface DeleteMapping {

    String value();

}
