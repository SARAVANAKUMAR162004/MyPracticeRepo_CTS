package com.example.demo.controller;

import java.util.*;

@RestController
@RequestMapping("/products")
public class ProductController {
    private Map<Integer, String> products = new HashMap<>();
    private int currentId = 1;

    // GET: Retrieve all products
    @GetMapping
    public ResponseEntity<List<String>> getAllProducts() {
        return null;
        //return ResponseEntity.ok(new ArrayList<>(products.values()));
    }

    // POST: Create a new product
    @PostMapping
    public ResponseEntity<String> createProduct(@RequestBody String name) {
        products.put(currentId++, name);
        //return new ResponseEntity<>("Product created", HttpStatus.CREATED);
        return null;
    }

    // PUT: Update an existing product
    @PutMapping("/{id}")
    public ResponseEntity<String> updateProduct(@PathVariable int id, @RequestBody String name) {
        if (products.containsKey(id)) {
            products.put(id, name);
            //return ResponseEntity.ok("Product updated");
        } else {
            //return new ResponseEntity<>("Product not found", HttpStatus.NOT_FOUND);
        }
        return null;
    }

    // DELETE: Delete a product
    @DeleteMapping("/{id}")
    public ResponseEntity<List<String>> deleteProduct(@PathVariable int id) {
        if (products.containsKey(id)) {
            products.remove(id);
            return ResponseEntity.ok("Product deleted");
        } else {
            //return new ResponseEntity<>("Product not found", HttpStatus.NOT_FOUND);
        }
        return null;
    }
}
