package com.example.demo.controller;

public @interface PutMapping {

    String value();

}
