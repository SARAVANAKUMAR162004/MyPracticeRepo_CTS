package com.cts.handson7.model;

public @interface Size {

    int min();

    int max();

    String message();

}
