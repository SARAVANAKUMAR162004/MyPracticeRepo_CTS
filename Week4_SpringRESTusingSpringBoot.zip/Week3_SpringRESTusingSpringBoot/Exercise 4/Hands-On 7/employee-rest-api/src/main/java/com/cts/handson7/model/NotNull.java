package com.cts.handson7.model;

public @interface NotNull {

    String message();

}
