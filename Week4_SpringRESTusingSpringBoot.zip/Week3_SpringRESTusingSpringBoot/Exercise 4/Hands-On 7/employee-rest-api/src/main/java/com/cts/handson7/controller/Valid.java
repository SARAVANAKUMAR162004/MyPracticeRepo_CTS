package com.cts.handson7.controller;

public @interface Valid {

}
