package com.cts.handson7.dao;

public @interface Repository {

}
