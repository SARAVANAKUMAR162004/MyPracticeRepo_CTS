package com.cts.handson7.model;

import jakarta.validation.constraints.*;

public class Department {
    @NotNull(message = "Id should not be null")
    @Digits(integer = 10, fraction = 0, message = "Id should be a number")
    private Integer id;

    @NotNull(message = "Name should not be null")
    @NotBlank(message = "Name should not be blank")
    @Size(min = 1, max = 30, message = "Name must be between 1 and 30 characters")
    private String name;

    // Getters and Setters
    // ...
}
