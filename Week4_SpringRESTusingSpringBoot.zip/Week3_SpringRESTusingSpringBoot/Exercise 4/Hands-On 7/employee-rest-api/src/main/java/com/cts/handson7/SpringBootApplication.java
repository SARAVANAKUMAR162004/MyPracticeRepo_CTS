package com.cts.handson7;

public @interface SpringBootApplication {

}
