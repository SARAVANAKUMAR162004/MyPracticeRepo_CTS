package com.cts.handson7.model;

import java.util.Date;
import java.util.List;

public class Employee {
    @NotNull(message = "Id should not be null")
    @Digits(integer = 10, fraction = 0, message = "Id should be a number")
    private Integer id;

    @NotNull(message = "Name should not be null")
    @NotBlank(message = "Name should not be blank")
    @Size(min = 1, max = 30, message = "Name must be between 1 and 30 characters")
    private String name;

    @NotNull(message = "Salary should not be null")
    @Min(value = 0, message = "Salary should be zero or above")
    private Double salary;

    @NotNull(message = "Permanent should not be null")
    private Boolean permanent;

    @NotNull(message = "Date of Birth should not be null")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    private Date dateOfBirth;

    @NotNull(message = "Department should not be null")
    private Department department;

    @NotNull(message = "Skills should not be null")
    private List<Skill> skills;

    // Getters and Setters
    // ...
}
