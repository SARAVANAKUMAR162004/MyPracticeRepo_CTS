package com.cts.handson7.model;

public @interface Digits {

    int integer();

    int fraction();

    String message();

}
