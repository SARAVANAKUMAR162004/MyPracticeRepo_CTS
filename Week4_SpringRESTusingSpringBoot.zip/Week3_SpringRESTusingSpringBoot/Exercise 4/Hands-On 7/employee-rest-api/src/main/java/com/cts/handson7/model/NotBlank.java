package com.cts.handson7.model;

public @interface NotBlank {

    String message();

}
