package com.cts.handson7.exception;

public @interface ResponseStatus {

}
