package com.cts.handson7.exception;

public class MethodArgumentNotValidException {

}
