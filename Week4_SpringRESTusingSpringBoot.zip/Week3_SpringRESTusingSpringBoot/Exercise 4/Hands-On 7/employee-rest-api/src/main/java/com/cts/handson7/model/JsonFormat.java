package com.cts.handson7.model;

public @interface JsonFormat {

}
