package com.cts.handson7.dao;

import com.cts.handson7.model.Employee;
import com.cts.handson7.exception.EmployeeNotFoundException;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class EmployeeDao {
    private static final List<Employee> employees = new ArrayList<>();

    public List<Employee> getAllEmployees() {
        return employees;
    }

    public void updateEmployee(Employee employee) {
        for (int i = 0; i < employees.size(); i++) {
            if (Objects.equals(employees.get(i).getId(), employee.getId())) {
                employees.set(i, employee);
                return;
            }
        }
        throw new EmployeeNotFoundException("Employee not found with id: " + employee.getId());
    }

    public void deleteEmployee(Integer id) {
        Iterator<Employee> iterator = employees.iterator();
        while (iterator.hasNext()) {
            if (Objects.equals(iterator.next().getId(), id)) {
                iterator.remove();
                return;
            }
        }
        throw new EmployeeNotFoundException("Employee not found with id: " + id);
    }

    // For demo: addEmployee, getEmployeeById, etc. can be added as needed
}
