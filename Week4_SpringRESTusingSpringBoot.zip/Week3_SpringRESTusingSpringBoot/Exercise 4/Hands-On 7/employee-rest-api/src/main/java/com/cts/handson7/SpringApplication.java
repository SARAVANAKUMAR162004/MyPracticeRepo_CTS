package com.cts.handson7;

public class SpringApplication {

}
