# Employee REST API

This project is a Spring Boot REST API for managing employees, departments, and skills.

## Features
- Update and delete employee endpoints
- Validation for Employee, Department, and Skill
- Exception handling for not found and invalid input
- MockMvc test for exceptional scenarios

## How to Run
1. Ensure you have Java 17+ and Maven installed.
2. In the `employee-rest-api` directory, run:
   ```
mvn spring-boot:run
   ```
3. Use Postman or similar tool to test the endpoints:
   - `PUT /employees` to update an employee
   - `DELETE /employees/{id}` to delete an employee
   - `GET /employees` to list all employees

## Testing
Run tests with:
```
mvn test
```

## Notes
- All endpoints expect/return JSON.
- Validation and error messages are returned in standard format.
