
public @interface Service {

}
