
public @interface Size {

}
