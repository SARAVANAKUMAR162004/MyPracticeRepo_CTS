
public @interface NotNull {

}
