
public class ConstraintViolation<T> {

}
