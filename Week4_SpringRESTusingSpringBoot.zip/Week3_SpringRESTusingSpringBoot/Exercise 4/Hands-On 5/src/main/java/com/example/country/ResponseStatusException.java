
public class ResponseStatusException {

}
