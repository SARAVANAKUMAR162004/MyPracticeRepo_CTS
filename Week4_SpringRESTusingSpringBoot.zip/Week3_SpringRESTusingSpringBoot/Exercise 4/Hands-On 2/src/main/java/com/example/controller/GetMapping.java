package com.example.controller;

public @interface GetMapping {

}
