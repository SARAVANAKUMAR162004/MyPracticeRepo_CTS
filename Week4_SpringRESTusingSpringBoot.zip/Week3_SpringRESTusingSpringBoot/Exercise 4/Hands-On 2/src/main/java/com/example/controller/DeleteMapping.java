package com.example.controller;

public @interface DeleteMapping {

}
