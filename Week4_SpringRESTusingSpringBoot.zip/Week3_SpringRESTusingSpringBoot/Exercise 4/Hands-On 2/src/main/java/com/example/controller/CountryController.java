package com.example.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/countries")
public class CountryController {
    private Map<String, Country> countryRepo = new HashMap<>();

    // Get all countries
    @GetMapping
    public List<Country> getAllCountries() {
        return new ArrayList<>(countryRepo.values());
    }

    // Get a specific country
    @GetMapping("/{code}")
    public ResponseEntity<Country> getCountry(@PathVariable String code) {
        Country country = countryRepo.get(code);
        if (country != null) {
            return ResponseEntity.ok(country);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Create a new country
    @PostMapping
    public ResponseEntity<Country> createCountry(@RequestBody Country country) {
        countryRepo.put(country.getCode(), country);
        return new ResponseEntity<>(country, HttpStatus.CREATED);
    }

    // Update a country
    @PutMapping
    public ResponseEntity<Country> updateCountry(@RequestBody Country country) {
        if (countryRepo.containsKey(country.getCode())) {
            countryRepo.put(country.getCode(), country);
            return ResponseEntity.ok(country);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete a country
    @DeleteMapping("/{code}")
    public ResponseEntity<Void> deleteCountry(@PathVariable String code) {
        if (countryRepo.containsKey(code)) {
            countryRepo.remove(code);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Sample Country class (inner static for demonstration)
    public static class Country {
        private String code;
        private String name;

        public Country() {
        }

        public Country(String code, String name) {
            this.code = code;
            this.name = name;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }
}
