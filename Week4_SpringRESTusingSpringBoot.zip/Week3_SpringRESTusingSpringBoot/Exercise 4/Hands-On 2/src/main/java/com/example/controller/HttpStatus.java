package com.example.controller;

public class HttpStatus {

}
