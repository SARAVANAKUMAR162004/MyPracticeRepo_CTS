

@RestController
public class CountryController {
    @PostMapping("/countries")
    public Country addCountry(@RequestBody Country country) {
        // Log the country details
        System.out.println("Country received: Code = " + country.getCode() + ", Name = " + country.getName());
        // Return the country object
        return country;
    }
}
