
public @interface PostMapping {

    String value();

}
