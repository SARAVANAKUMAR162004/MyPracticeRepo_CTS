package com.example.country;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CountryController {
    private static final Logger logger = LoggerFactory.getLogger(CountryController.class);

    @PostMapping("/countries")
    public void addCountry(@RequestBody(required = false) Country country) {
        logger.info("Start");
        // You can add logic to process the country object here
    }
}
