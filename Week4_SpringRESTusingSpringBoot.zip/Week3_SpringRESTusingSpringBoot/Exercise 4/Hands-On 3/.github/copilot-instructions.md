<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This is a Spring Boot RESTful web service project for handling POST requests for a Country entity. Always use @RestController and @PostMapping for REST endpoints.
