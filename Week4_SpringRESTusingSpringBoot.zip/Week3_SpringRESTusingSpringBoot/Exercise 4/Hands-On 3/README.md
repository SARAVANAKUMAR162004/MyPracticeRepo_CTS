# Country Service Spring Boot Application

This project is a minimal Spring Boot RESTful web service for handling POST requests for a Country entity.

## How to Run

1. Make sure you have Java 11+ and Maven installed.
2. In the project root, run:
   
   mvn spring-boot:run

3. The service will start on port 8090.

## Test the POST Endpoint

You can test the endpoint using curl or Postman:

```
curl -i -X POST -s http://localhost:8090/countries
```

You should see output similar to:

    HTTP/1.1 200
    Content-Length: 0
    Date: ...

Check the console for the log message:

    Start

## Project Structure
- `Country.java`: Model class for Country entity
- `CountryController.java`: REST controller with POST endpoint
- `CountryApplication.java`: Main Spring Boot application

---

This project was generated for a hands-on Spring Boot RESTful web service exercise.
