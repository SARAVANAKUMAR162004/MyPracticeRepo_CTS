package com.example.dao;

import com.example.model.Employee;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDao {
    private static ArrayList<Employee> EMPLOYEE_LIST;

    public EmployeeDao() {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext();
        EMPLOYEE_LIST = (ArrayList<Employee>) context.getBean("employeeList");
    }

    public List<Employee> getAllEmployees() {
        return EMPLOYEE_LIST;
    }
}
