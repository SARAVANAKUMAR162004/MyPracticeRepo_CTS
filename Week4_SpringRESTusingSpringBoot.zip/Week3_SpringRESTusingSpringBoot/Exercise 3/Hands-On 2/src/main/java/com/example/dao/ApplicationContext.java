package com.example.dao;

import java.util.ArrayList;

import com.example.model.Employee;

public class ApplicationContext {

    public ArrayList<Employee> getBean(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getBean'");
    }

}
