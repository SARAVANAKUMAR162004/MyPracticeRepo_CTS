
public @interface PathVariable {

}
