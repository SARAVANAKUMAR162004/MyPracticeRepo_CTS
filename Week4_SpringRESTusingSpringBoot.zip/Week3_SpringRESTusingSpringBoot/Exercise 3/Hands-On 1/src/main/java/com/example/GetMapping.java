
public @interface GetMapping {

}
