package com.example.employee;

public class SpringApplication {

}
