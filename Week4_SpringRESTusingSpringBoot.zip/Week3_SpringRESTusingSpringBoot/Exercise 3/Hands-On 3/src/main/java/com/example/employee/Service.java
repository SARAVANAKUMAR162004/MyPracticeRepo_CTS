package com.example.employee;

public @interface Service {

}
