package com.example.employee;

import java.util.*;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDao {
    private static final List<Employee> employees = new ArrayList<>();

    static {
        employees.add(new Employee(1, "John Doe", "HR"));
        employees.add(new Employee(2, "Jane Smith", "Finance"));
        employees.add(new Employee(3, "Mike Brown", "IT"));
    }

    public List<Employee> getAllEmployees() {
        return employees;
    }
}
