package com.example.department;

public @interface Value {

    String value();

}
