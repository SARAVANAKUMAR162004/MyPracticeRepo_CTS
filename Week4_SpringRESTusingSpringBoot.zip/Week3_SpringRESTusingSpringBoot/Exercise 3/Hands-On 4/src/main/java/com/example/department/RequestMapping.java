package com.example.department;

public @interface RequestMapping {

    String value();

}
