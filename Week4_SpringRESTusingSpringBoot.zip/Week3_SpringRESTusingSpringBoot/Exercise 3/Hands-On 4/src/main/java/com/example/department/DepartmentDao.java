package com.example.department;

import java.util.*;

@Repository
public class DepartmentDao {
    public static List<Department> DEPARTMENT_LIST = new ArrayList<>();

    @Value("#{departmentList}")
    private List<Department> injectedDepartments;

    @PostConstruct
    public void init() {
        if (injectedDepartments != null) {
            DEPARTMENT_LIST.addAll(injectedDepartments);
        }
    }

    public List<Department> getAllDepartments() {
        return DEPARTMENT_LIST;
    }
}
