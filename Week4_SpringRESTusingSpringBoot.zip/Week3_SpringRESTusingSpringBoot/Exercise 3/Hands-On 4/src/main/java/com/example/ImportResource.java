package com.example;

public @interface ImportResource {

    String value();

}
