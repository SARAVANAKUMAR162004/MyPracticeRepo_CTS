package com.example.department;

import java.lang.System.Logger;

public class LoggerFactory {

    public static Logger getLogger(Class<DepartmentService> class1) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getLogger'");
    }

}
