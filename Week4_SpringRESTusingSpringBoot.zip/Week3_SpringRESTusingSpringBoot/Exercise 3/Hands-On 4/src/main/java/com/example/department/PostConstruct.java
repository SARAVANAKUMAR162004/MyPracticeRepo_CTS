package com.example.department;

public @interface PostConstruct {

}
