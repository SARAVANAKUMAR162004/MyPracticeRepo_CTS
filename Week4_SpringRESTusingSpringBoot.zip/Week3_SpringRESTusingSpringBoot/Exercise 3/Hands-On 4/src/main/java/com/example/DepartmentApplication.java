package com.example;

@SpringBootApplication
@ImportResource("classpath:departments.xml")
public class DepartmentApplication {
    public static void main(String[] args) {
        SpringApplication.run(DepartmentApplication.class, args);
    }
}
