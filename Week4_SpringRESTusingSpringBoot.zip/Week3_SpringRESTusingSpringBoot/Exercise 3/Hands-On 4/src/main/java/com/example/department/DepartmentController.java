package com.example.department;

import java.lang.System.Logger;
import java.util.List;

@RestController
@RequestMapping("/departments")
public class DepartmentController {
    //private static final Logger logger = LoggerFactory.getLogger(DepartmentController.class);

    @Autowired
    private DepartmentService departmentService;

    @GetMapping
    public List<Department> getAllDepartments() {
        //((Object) logger).info("DepartmentController: /departments called");
        return departmentService.getAllDepartments();
    }
}
