package com.example.department;

import java.lang.System.Logger;
import java.util.List;

@Service
public class DepartmentService {
    //private static final Logger logger = LoggerFactory.getLogger(DepartmentService.class);

    @Autowired
    private DepartmentDao departmentDao;

    public List<Department> getAllDepartments() {
        //((Object) logger).info("DepartmentService: getAllDepartments called");
        return departmentDao.getAllDepartments();
    }
}
