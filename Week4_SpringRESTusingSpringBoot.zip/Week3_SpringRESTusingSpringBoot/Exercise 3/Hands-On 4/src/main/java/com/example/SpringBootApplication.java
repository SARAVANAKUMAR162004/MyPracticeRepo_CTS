package com.example;

public @interface SpringBootApplication {

}
