package com.example;

public class SpringApplication {

    public static void run(Class<DepartmentApplication> class1, String[] args) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'run'");
    }

}
