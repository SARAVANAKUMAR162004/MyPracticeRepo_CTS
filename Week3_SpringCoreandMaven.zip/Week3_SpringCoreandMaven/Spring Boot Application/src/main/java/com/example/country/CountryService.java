package com.example.country;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Optional;

@Service
public class CountryService {
    @Autowired
    private CountryRepository countryRepository;

    @Transactional
    public void updateCountry(String code, String name) {
        Optional<Country> countryOpt = countryRepository.findById(code);
        if (countryOpt.isPresent()) {
            Country country = countryOpt.get();
            country.setName(name);
            countryRepository.save(country);
        } else {
            throw new RuntimeException("Country not found with code: " + code);
        }
    }
}
