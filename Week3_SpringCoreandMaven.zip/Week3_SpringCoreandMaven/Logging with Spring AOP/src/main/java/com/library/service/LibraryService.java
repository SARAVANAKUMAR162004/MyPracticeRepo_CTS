package com.library.service;

public class LibraryService {
    public void issueBook(String bookName, String memberName) {
        System.out.println(memberName + " issued the book: " + bookName);
        // Simulate some processing time
        try {
            Thread.sleep(500);
        } catch (InterruptedException ignored) {
        }
    }

    public void returnBook(String bookName, String memberName) {
        System.out.println(memberName + " returned the book: " + bookName);
        // Simulate some processing time
        try {
            Thread.sleep(300);
        } catch (InterruptedException ignored) {
        }
    }
}
