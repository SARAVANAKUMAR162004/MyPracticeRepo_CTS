<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->
This project is a Maven-based Spring application demonstrating logging with Spring AOP. Use best practices for Spring configuration, AOP, and Java code style.
