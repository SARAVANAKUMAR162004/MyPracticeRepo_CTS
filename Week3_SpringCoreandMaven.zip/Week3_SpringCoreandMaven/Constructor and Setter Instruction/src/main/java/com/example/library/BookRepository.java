package com.example.library;

public class BookRepository {
    public String getBookInfo() {
        return "Book information from repository.";
    }
}
