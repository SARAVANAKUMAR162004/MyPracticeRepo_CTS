package com.example.library;

public class BookService {
    private BookRepository bookRepository;
    private String serviceName;

    // Constructor Injection
    public BookService(String serviceName) {
        this.serviceName = serviceName;
    }

    // Setter Injection
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void displayServiceDetails() {
        System.out.println("Service Name: " + serviceName);
        if (bookRepository != null) {
            System.out.println(bookRepository.getBookInfo());
        } else {
            System.out.println("BookRepository not injected!");
        }
    }
}
