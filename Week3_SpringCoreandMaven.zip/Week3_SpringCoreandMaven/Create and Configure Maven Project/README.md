# LibraryManagement

This is a Maven-based Java project for a Library Management application. It uses Spring Context, Spring AOP, and Spring WebMVC. The Maven Compiler Plugin is configured for Java 1.8.

## How to Build

1. Make sure you have Java 1.8 and Maven installed.
2. Run `mvn clean install` to build the project.

## How to Run

- This project is a template. Add your application code in the `src/main/java` directory.

## Features
- Spring Context
- Spring AOP
- Spring WebMVC

## Configuration
- Maven Compiler Plugin set to Java 1.8

---

For more details, see the `pom.xml` file.
