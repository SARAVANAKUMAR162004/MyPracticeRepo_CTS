<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This project is a Maven-based Java application for Library Management, using Spring Context, Spring AOP, and Spring WebMVC. Follow best practices for Maven and Spring development.
