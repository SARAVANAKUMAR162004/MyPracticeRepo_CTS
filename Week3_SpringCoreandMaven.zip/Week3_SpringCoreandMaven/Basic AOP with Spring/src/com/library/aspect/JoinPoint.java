package com.library.aspect;

public class JoinPoint {

}
