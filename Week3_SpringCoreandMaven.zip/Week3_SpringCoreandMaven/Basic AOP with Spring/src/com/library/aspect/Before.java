package com.library.aspect;

public @interface Before {

}
