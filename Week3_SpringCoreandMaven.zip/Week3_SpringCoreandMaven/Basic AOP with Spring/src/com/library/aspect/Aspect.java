package com.library.aspect;

public @interface Aspect {

}
