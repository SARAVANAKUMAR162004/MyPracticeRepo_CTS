package com.library.aspect;

public @interface Component {

}
