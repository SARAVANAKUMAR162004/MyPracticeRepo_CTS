package com.example.library;

public class BookRepository {
    public void printRepository() {
        System.out.println("BookRepository: Accessing book data...");
    }
}
