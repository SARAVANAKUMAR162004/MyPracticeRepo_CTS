package com.example.library;

public class BookService {
    private BookRepository bookRepository;

    // Setter for dependency injection
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void printService() {
        System.out.println("BookService: Managing books...");
        if (bookRepository != null) {
            bookRepository.printRepository();
        } else {
            System.out.println("BookRepository not set!");
        }
    }
}
