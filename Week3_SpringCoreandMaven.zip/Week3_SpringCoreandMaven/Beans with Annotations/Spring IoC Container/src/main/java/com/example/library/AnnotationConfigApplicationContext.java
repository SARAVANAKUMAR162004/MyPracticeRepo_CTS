package com.example.library;

public record AnnotationConfigApplicationContext() {

}
