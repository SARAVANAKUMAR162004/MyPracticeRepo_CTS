package com.example.library;

public @interface Repository {

}
