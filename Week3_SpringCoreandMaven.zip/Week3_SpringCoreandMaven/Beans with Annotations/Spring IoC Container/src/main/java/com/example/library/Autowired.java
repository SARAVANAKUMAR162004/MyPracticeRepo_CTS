package com.example.library;

public @interface Autowired {

}
