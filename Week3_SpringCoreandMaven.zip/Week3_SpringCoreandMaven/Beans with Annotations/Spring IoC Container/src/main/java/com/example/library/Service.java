package com.example.library;

public @interface Service {

}
