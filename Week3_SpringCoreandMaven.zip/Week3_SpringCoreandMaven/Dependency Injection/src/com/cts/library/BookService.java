package com.cts.library;

public class BookService {
    private BookRepository bookRepository;

    // Setter for dependency injection
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void showBooks() {
        if (bookRepository != null) {
            bookRepository.displayBooks();
        } else {
            System.out.println("BookRepository is not injected!");
        }
    }
}
