package com.cts.library;

public class BookRepository {
    public void displayBooks() {
        System.out.println("Displaying books from the repository.");
    }
}
