package com.cts.library;

public class ClassPathXmlApplicationContext {

    public ClassPathXmlApplicationContext(String string) {
        //TODO Auto-generated constructor stub
    }

    public BookService getBean(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getBean'");
    }

    public void close() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'close'");
    }

}
