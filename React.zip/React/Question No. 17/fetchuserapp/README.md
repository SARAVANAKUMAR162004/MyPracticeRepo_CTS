# Fetch User App

This React application fetches user details from https://api.randomuser.me/ and displays the title, first name, and image of a user.

## How to Run

1. Install dependencies:
   ```sh
   npm install
   ```
2. Start the app:
   ```sh
   npm start
   ```

The app will open in your browser and display a random user's details.
