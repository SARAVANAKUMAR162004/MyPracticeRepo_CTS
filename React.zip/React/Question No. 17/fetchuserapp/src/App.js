import React from 'react';
import Getuser from './Getuser';

function App() {
  return (
    <div className="App">
      <Getuser />
    </div>
  );
}

export default App;
