import React from 'react';
import Counter from './Counter';
import CurrencyConvertor from './CurrencyConvertor';

function sayWelcome(message) {
  alert(message);
}

function handlePress(e) {
  alert('I was clicked');
  console.log(e); // SyntheticEvent object
}

function App() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>React Event Examples App</h1>
      <Counter />
      <br />
      <button onClick={() => sayWelcome('Welcome')}>Say Welcome</button>
      <br /><br />
      <button onClick={handlePress}>OnPress</button>
      <br /><br />
      <CurrencyConvertor />
    </div>
  );
}

export default App;
