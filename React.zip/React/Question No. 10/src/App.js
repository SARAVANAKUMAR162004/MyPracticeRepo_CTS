import React from "react";

// Example office data
const offices = [
  {
    name: "Tech Park Tower",
    rent: 58000,
    address: "101 Silicon Avenue, Chennai",
    image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80"
  },
  {
    name: "Greenfield Workspace",
    rent: 62000,
    address: "202 Green Road, Bangalore",
    image: "https://images.unsplash.com/photo-1464983953574-0892a716854b?auto=format&fit=crop&w=400&q=80"
  },
  {
    name: "City Center Hub",
    rent: 45000,
    address: "303 Downtown St, Hyderabad",
    image: "https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=400&q=80"
  }
];

function getRentColor(rent) {
  return rent < 60000 ? "red" : "green";
}

function App() {
  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "2rem" }}>
      {/* Heading using JSX */}
      <h1>Office Space Rental App</h1>
      {/* Render office list */}
      {offices.map((office, idx) => (
        <div key={idx} style={{ border: "1px solid #ddd", borderRadius: "8px", margin: "1rem 0", padding: "1rem", boxShadow: "0 2px 8px #eee" }}>
          {/* Attribute for image */}
          <img src={office.image} alt={office.name} style={{ width: "100%", maxWidth: "350px", borderRadius: "8px" }} />
          <h2>{office.name}</h2>
          <p>
            Rent: <span style={{ color: getRentColor(office.rent), fontWeight: "bold" }}>{office.rent}</span>
          </p>
          <p>Address: {office.address}</p>
        </div>
      ))}
    </div>
  );
}

export default App;
