# BlogApp

A simple React application demonstrating component lifecycle methods:
- `componentDidMount()` for data fetching
- `componentDidCatch()` for error handling

## How to Run

1. Install dependencies:
   ```powershell
   npm install
   ```
2. Start the development server:
   ```powershell
   npm start
   ```

## Features
- Fetches posts from JSONPlaceholder API
- Displays posts with title and body
- Handles errors gracefully
