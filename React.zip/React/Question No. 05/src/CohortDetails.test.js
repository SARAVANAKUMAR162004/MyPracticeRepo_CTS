import { render, screen } from '@testing-library/react';
import CohortDetails from './CohortDetails';

test('renders cohort name and status', () => {
  const cohort = {
    name: 'React Bootcamp',
    status: 'ongoing',
    startDate: '2025-07-01',
    endDate: '2025-08-01',
  };
  render(<CohortDetails cohort={cohort} />);
  expect(screen.getByText('React Bootcamp')).toBeInTheDocument();
  expect(screen.getByText('ongoing')).toBeInTheDocument();
});
