import React, { useState } from 'react';
import ListofPlayers from './ListofPlayers';
import IndianPlayers from './IndianPlayers';

function App() {
  // Flag to toggle between components
  const [flag, setFlag] = useState(true);

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>Cricket App</h1>
      <button onClick={() => setFlag(!flag)} style={{ marginBottom: '20px' }}>
        Toggle Flag
      </button>
      {flag ? <ListofPlayers /> : <IndianPlayers />}
    </div>
  );
}

export default App;
