import React from 'react';

// Array of 11 players with name and score
const players = [
  { name: 'Virat Kohli', score: 85 },
  { name: 'Rohit Sharma', score: 92 },
  { name: 'MS Dhoni', score: 65 },
  { name: 'KL Rahul', score: 74 },
  { name: 'Hardik Pandya', score: 55 },
  { name: 'Jasprit Bumrah', score: 80 },
  { name: 'Ravindra Jadeja', score: 68 },
  { name: 'Shikhar Dhawan', score: 77 },
  { name: 'Rishabh Pant', score: 60 },
  { name: 'Yuzvendra Chahal', score: 72 },
  { name: 'Bhuvneshwar Kumar', score: 88 }
];

// Filter players with score >= 70 using arrow function
const highScorers = players.filter(player => player.score >= 70);

const ListofPlayers = () => (
  <div>
    <h2>Players with score ≥ 70</h2>
    <ul>
      {highScorers.map(player => (
        <li key={player.name}>{player.name}: {player.score}</li>
      ))}
    </ul>
  </div>
);

export default ListofPlayers;
