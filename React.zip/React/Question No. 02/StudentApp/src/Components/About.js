import React from 'react';

function About() {
  return (
    <div>
      Welcome to the About page of the Student Management Portal
    </div>
  );
}

export default About;
