import React from 'react';

function Contact() {
  return (
    <div>
      Welcome to the Contact page of the Student Management Portal
    </div>
  );
}

export default Contact;
