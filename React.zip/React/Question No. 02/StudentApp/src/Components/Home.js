import React from 'react';

function Home() {
  return (
    <div>
      Welcome to the Home page of Student Management Portal
    </div>
  );
}

export default Home;
