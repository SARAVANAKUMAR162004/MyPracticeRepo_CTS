const CohortData = [
  {
    code: 'COH2025A',
    name: 'React Bootcamp',
    status: 'Ongoing',
    startDate: '2025-07-01',
    endDate: '2025-08-01',
  },
  {
    code: 'COH2025B',
    name: 'Node.js Mastery',
    status: 'Completed',
    startDate: '2025-05-01',
    endDate: '2025-06-01',
  },
];

export default CohortData;
