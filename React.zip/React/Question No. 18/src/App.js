import React from 'react';
import CohortDetails from './CohortDetails';
import CohortData from './Cohort';

function App() {
  return (
    <div className="App">
      <h2>Cognizant Academy Cohorts</h2>
      {CohortData.map((cohort) => (
        <CohortDetails key={cohort.code} cohort={cohort} />
      ))}
    </div>
  );
}

export default App;
