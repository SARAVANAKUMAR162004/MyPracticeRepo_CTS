# Ticket Raising App

This is a simple React application to raise complaints and generate a reference number for follow-up.

## Features

- Controlled form with textbox (employee name) and textarea (complaint)
- Reference number generated on submission
- Alert with complaint details and reference number

## Getting Started

1. Install dependencies:
   ```sh
   npm install
   ```
2. Start the development server:
   ```sh
   npm start
   ```
3. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Project Structure

- `src/ComplaintRegister.js`: Main form component
- `src/App.js`: App entry point
- `src/index.js`: React DOM rendering

---
