import React, { useState } from 'react';

function ComplaintRegister() {
  const [employeeName, setEmployeeName] = useState('');
  const [complaint, setComplaint] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const referenceNumber = 'REF' + Math.floor(100000 + Math.random() * 900000);
    alert(
      `Complaint submitted!\nEmployee Name: ${employeeName}\nComplaint: ${complaint}\nReference Number: ${referenceNumber}`
    );
    setEmployeeName('');
    setComplaint('');
  };

  return (
    <div style={{ maxWidth: 400, margin: '2rem auto', padding: 20, border: '1px solid #ccc', borderRadius: 8 }}>
      <h2>Raise a Complaint</h2>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: 12 }}>
          <label>
            Employee Name:<br />
            <input
              type="text"
              value={employeeName}
              onChange={(e) => setEmployeeName(e.target.value)}
              required
              style={{ width: '100%', padding: 8 }}
            />
          </label>
        </div>
        <div style={{ marginBottom: 12 }}>
          <label>
            Complaint:<br />
            <textarea
              value={complaint}
              onChange={(e) => setComplaint(e.target.value)}
              required
              rows={4}
              style={{ width: '100%', padding: 8 }}
            />
          </label>
        </div>
        <button type="submit" style={{ padding: '8px 16px' }}>Submit Complaint</button>
      </form>
    </div>
  );
}

export default ComplaintRegister;
