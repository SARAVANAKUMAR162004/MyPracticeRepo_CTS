import React, { useState } from 'react';
import GitClient from './GitClient';

function App() {
  const [repos, setRepos] = useState([]);
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchRepos = async () => {
    setLoading(true);
    const client = new GitClient();
    const repoNames = await client.getRepositories(username);
    setRepos(repoNames);
    setLoading(false);
  };

  return (
    <div>
      <h1>GitHub Repositories</h1>
      <input
        value={username}
        onChange={e => setUsername(e.target.value)}
        placeholder="Enter GitHub username"
      />
      <button onClick={fetchRepos}>Fetch Repos</button>
      {loading && <p>Loading...</p>}
      <ul>
        {repos.map(repo => (
          <li key={repo}>{repo}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
