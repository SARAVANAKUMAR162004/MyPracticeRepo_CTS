# myfirstreact

This is a simple React application that displays a heading:

```
welcome to the first session of React
```

## How to run

1. Install dependencies:
   ```powershell
   npm install
   ```
2. Build the project:
   ```powershell
   npm run build
   ```
3. Start the server:
   ```powershell
   npm start
   ```
4. Open your browser and go to `http://localhost:3000` (or the port shown in the terminal).
