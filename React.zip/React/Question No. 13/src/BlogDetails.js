import React from 'react';

const BlogDetails = ({ blog }) => (
  <div className="card">
    <h3>Blog Details</h3>
    <p><strong>Title:</strong> {blog.title}</p>
    <p><strong>Author:</strong> {blog.author}</p>
    <p><strong>Date:</strong> {blog.date}</p>
  </div>
);

export default BlogDetails;
