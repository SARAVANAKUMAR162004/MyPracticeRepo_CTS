import React, { useState } from 'react';
import BookDetails from './BookDetails';
import BlogDetails from './BlogDetails';
import CourseList from './CourseList';

const books = [
  { title: 'React Explained', author: 'Zac Gordon', year: 2020 },
  { title: 'Learning React', author: 'Alex Banks', year: 2021 }
];
const blogs = [
  { title: 'React Patterns', author: 'Michael Chan', date: '2023-01-10' },
  { title: 'Hooks in Depth', author: 'Dan Abramov', date: '2023-02-15' }
];
const courses = [
  { id: 1, name: 'React Basics', instructor: 'Sarah', duration: '4 weeks' },
  { id: 2, name: 'Advanced React', instructor: 'John', duration: '6 weeks' }
];

function App() {
  const [showBook, setShowBook] = useState(true);
  const [showBlog, setShowBlog] = useState(false);
  const [showCourses, setShowCourses] = useState(false);
  const [selectedBook, setSelectedBook] = useState(0);
  const [selectedBlog, setSelectedBlog] = useState(0);

  // Conditional rendering using if/else
  let bookSection;
  if (showBook) {
    bookSection = <BookDetails book={books[selectedBook]} />;
  } else {
    bookSection = <p>Book details are hidden.</p>;
  }

  // Conditional rendering using ternary
  const blogSection = showBlog ? (
    <BlogDetails blog={blogs[selectedBlog]} />
  ) : (
    <p>Blog details are hidden.</p>
  );

  // Conditional rendering using &&
  const coursesSection = showCourses && <CourseList courses={courses} />;

  // Conditional rendering using switch
  function renderSection(type) {
    switch (type) {
      case 'book':
        return bookSection;
      case 'blog':
        return blogSection;
      case 'courses':
        return coursesSection;
      default:
        return <p>Select a section to view details.</p>;
    }
  }

  // Conditional rendering using IIFE
  const iifeSection = (() => {
    if (showBook) return <BookDetails book={books[1]} />;
    if (showBlog) return <BlogDetails blog={blogs[1]} />;
    if (showCourses) return <CourseList courses={courses} />;
    return <p>No details to show.</p>;
  })();

  return (
    <div style={{ padding: 20 }}>
      <h1>Blogger App - Conditional Rendering Demo</h1>
      <div>
        <button onClick={() => { setShowBook(true); setShowBlog(false); setShowCourses(false); }}>Show Book</button>
        <button onClick={() => { setShowBook(false); setShowBlog(true); setShowCourses(false); }}>Show Blog</button>
        <button onClick={() => { setShowBook(false); setShowBlog(false); setShowCourses(true); }}>Show Courses</button>
      </div>
      <hr />
      <h2>Switch Statement Example</h2>
      {renderSection(showBook ? 'book' : showBlog ? 'blog' : showCourses ? 'courses' : '')}
      <hr />
      <h2>IIFE Example</h2>
      {iifeSection}
      <hr />
      <h2>List Rendering with Keys</h2>
      <CourseList courses={courses} />
    </div>
  );
}

export default App;
