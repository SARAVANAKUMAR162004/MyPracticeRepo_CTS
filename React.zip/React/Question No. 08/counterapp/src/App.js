import React from 'react';
import CountPeople from './CountPeople';

function App() {
  return (
    <div>
      <CountPeople />
    </div>
  );
}

export default App;
