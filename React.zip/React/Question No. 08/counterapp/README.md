# Counter App

This is a simple React application that tracks the number of people entering and exiting a mall.

## Features
- Displays entry and exit counts
- Two buttons: Login (increment entry), Exit (increment exit)
- Uses React class component and state

## How to Run
1. Install dependencies:
   ```
   npm install
   ```
2. Start the app:
   ```
   npm start
   ```
3. Open your browser to `http://localhost:3000` to view the app.

## File Structure
- `src/CountPeople.js`: Main counter component
- `src/App.js`: App entry point
- `src/index.js`: React DOM rendering
- `public/index.html`: HTML template

---
