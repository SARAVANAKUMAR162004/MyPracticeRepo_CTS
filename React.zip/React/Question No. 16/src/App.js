import React from "react";
import Register from "./register";

function App() {
  return (
    <div className="App">
      <Register />
    </div>
  );
}

export default App;
