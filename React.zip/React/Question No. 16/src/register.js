import React, { useState } from "react";

function Register() {
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  // Validation function
  const validate = (fieldValues = form) => {
    let temp = { ...errors };

    if ("name" in fieldValues)
      temp.name = fieldValues.name.length >= 5 ? "" : "Name must be at least 5 characters.";
    if ("email" in fieldValues)
      temp.email =
        fieldValues.email.includes("@") && fieldValues.email.includes(".")
          ? ""
          : "Email must contain @ and .";
    if ("password" in fieldValues)
      temp.password =
        fieldValues.password.length >= 8 ? "" : "Password must be at least 8 characters.";

    setErrors({ ...temp });

    // Return true if no errors
    return Object.values(temp).every((x) => x === "");
  };

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
    validate({ [name]: value });
  };

  // Handle form submit
  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      setSubmitted(true);
    } else {
      setSubmitted(false);
    }
  };

  return (
    <div style={{ maxWidth: 400, margin: "auto", padding: 20, border: "1px solid #ccc", borderRadius: 8 }}>
      <h2>Register</h2>
      <form onSubmit={handleSubmit} noValidate>
        <div style={{ marginBottom: 12 }}>
          <label>Name:</label>
          <input
            type="text"
            name="name"
            value={form.name}
            onChange={handleChange}
            style={{ width: "100%", padding: 8, marginTop: 4 }}
          />
          <div style={{ color: "red", fontSize: 12 }}>{errors.name}</div>
        </div>
        <div style={{ marginBottom: 12 }}>
          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={form.email}
            onChange={handleChange}
            style={{ width: "100%", padding: 8, marginTop: 4 }}
          />
          <div style={{ color: "red", fontSize: 12 }}>{errors.email}</div>
        </div>
        <div style={{ marginBottom: 12 }}>
          <label>Password:</label>
          <input
            type="password"
            name="password"
            value={form.password}
            onChange={handleChange}
            style={{ width: "100%", padding: 8, marginTop: 4 }}
          />
          <div style={{ color: "red", fontSize: 12 }}>{errors.password}</div>
        </div>
        <button type="submit" style={{ padding: "8px 16px" }}>Register</button>
      </form>
      {submitted && <div style={{ color: "green", marginTop: 16 }}>Registration Successful!</div>}
    </div>
  );
}

export default Register;
