import React, { useState } from 'react';
import GuestPage from './GuestPage';
import UserPage from './UserPage';
import LoginLogoutButton from './LoginLogoutButton';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Element variable for page content
  let pageContent;
  if (isLoggedIn) {
    pageContent = <UserPage />;
  } else {
    pageContent = <GuestPage />;
  }

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Ticket Booking App</h1>
      <LoginLogoutButton
        isLoggedIn={isLoggedIn}
        onLogin={() => setIsLoggedIn(true)}
        onLogout={() => setIsLoggedIn(false)}
      />
      {pageContent}
    </div>
  );
}

export default App;
