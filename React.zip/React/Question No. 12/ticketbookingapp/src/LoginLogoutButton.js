import React from 'react';

function LoginLogoutButton({ isLoggedIn, onLogin, onLogout }) {
  return (
    <button onClick={isLoggedIn ? onLogout : onLogin} style={{ marginBottom: '30px' }}>
      {isLoggedIn ? 'Logout' : 'Login'}
    </button>
  );
}

export default LoginLogoutButton;
